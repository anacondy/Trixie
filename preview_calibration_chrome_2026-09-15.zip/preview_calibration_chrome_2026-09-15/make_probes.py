#!/usr/bin/env python3
"""Generate standard preview probe pack. Run once."""
import os, zipfile, tarfile, io, json

TS = "Tue Sep 15 16:30:47 UTC 2026"
D = "/home/user/preview_probe"
os.makedirs(D, exist_ok=True)

def w(name, data):
    p = os.path.join(D, name)
    mode = "wb" if isinstance(data, bytes) else "w"
    with open(p, mode) as f:
        f.write(data)
    return p

# 01 .md
w("probe.md", f"# PROBE md OK\n\n{TS}\n\nProbe markdown document for viewer calibration.\n")
# 02 .txt
w("probe.txt", f"PROBE txt OK\n{TS}\nProbe plain-text document for viewer calibration.\n")
# 03 .html
w("probe.html", f"<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>probe</title></head>\n<body><h1>PROBE html OK</h1><p>{TS}</p></body></html>\n")
# 04 .py
w("probe.py", f"# PROBE py OK\n# {TS}\n\ndef main():\n    print(\"PROBE py OK {TS}\")\n\nif __name__ == \"__main__\":\n    main()\n")
# 05 .json
w("probe.json", json.dumps({"probe": "PROBE json OK", "ts": TS}, indent=2) + "\n")
# 06 .csv
w("probe.csv", f"id,message,ts\n1,PROBE csv OK,{TS}\n2,second row,{TS}\n")
# 07 .png / 13 .jpg via Pillow
from PIL import Image, ImageDraw
def make_img(ext, fname, fmt):
    img = Image.new("RGB", (800, 400), "white")
    d = ImageDraw.Draw(img)
    d.text((40, 120), f"PROBE {ext} OK", fill="black")
    d.text((40, 180), TS, fill="black")
    d.rectangle([20, 20, 780, 380], outline="black", width=3)
    img.save(os.path.join(D, fname), fmt)
make_img("png", "probe.png", "PNG")
make_img("jpg", "probe.jpg", "JPEG")
# 08 .svg
w("probe.svg", f"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"800\" height=\"400\"><rect x=\"20\" y=\"20\" width=\"760\" height=\"360\" fill=\"white\" stroke=\"black\" stroke-width=\"3\"/><text x=\"40\" y=\"150\" font-size=\"36\">PROBE svg OK</text><text x=\"40\" y=\"200\" font-size=\"20\">{TS}</text></svg>\n")
# 09 .pdf (hand-built minimal, valid xref)
def build_pdf(path):
    t1, t2 = "PROBE pdf OK", TS
    content = f"BT /F1 18 Tf 72 720 Td ({t1}) Tj 0 -30 Td /F1 12 Tf ({t2}) Tj ET"
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content.encode() + b"\nendstream",
    ]
    out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offs = []
    for i, body in enumerate(objs, 1):
        offs.append(len(out))
        out += f"{i} 0 obj\n".encode() + body + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode()
    for o in offs:
        out += f"{o:010d} 00000 n \n".encode()
    out += f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    open(path, "wb").write(bytes(out))
build_pdf(os.path.join(D, "probe.pdf"))
# 10 .docx
from docx import Document
doc = Document()
doc.add_heading("PROBE docx OK", level=1)
doc.add_paragraph(TS)
doc.add_paragraph("Probe Word document for viewer calibration.")
doc.save(os.path.join(D, "probe.docx"))
# 11 .xlsx
from openpyxl import Workbook
wb = Workbook(); ws = wb.active; ws.title = "probe"
ws["A1"] = "PROBE xlsx OK"; ws["A2"] = TS
wb.save(os.path.join(D, "probe.xlsx"))
# 12 .pptx
from pptx import Presentation
from pptx.util import Inches
prs = Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[6])
box = slide.shapes.add_textbox(Inches(0.5), Inches(0.5), Inches(9), Inches(3))
tf = box.text_frame; tf.text = "PROBE pptx OK"
tf.add_paragraph().text = TS
prs.save(os.path.join(D, "probe.pptx"))
# 14 .mp3 (hand-built: ID3v2.3 + valid MPEG frames)
def syncsafe(n):
    return bytes([(n >> 21) & 0x7F, (n >> 14) & 0x7F, (n >> 7) & 0x7F, n & 0x7F])
title = ("PROBE mp3 OK " + TS).encode("latin-1", "replace")
tit2 = b"TIT2" + len(b"\x00" + title).to_bytes(4, "big") + b"\x00\x00\x00" + title
mp3 = b"ID3\x03\x00\x00" + syncsafe(len(tit2)) + tit2
frame = bytes([0xFF, 0xFB, 0x90, 0x00]) + bytes(417 - 4)
mp3 += frame * 32
w("probe.mp3", mp3)
# 15 .mp4 (hand-built minimal ISO BMFF: ftyp+free+moov/mvhd+mdat)
def box(typ, payload):
    return (8 + len(payload)).to_bytes(4, "big") + typ + payload
ftyp = box(b"ftyp", b"isom" + (0).to_bytes(4, "big") + b"isomiso2mp41")
free = box(b"free", ("PROBE mp4 OK " + TS).encode())
mvhd = (b"\x00\x00\x00\x00" + b"\x00" * 8 + (1000).to_bytes(4, "big") + (1000).to_bytes(4, "big")
        + (0x00010000).to_bytes(4, "big") + (0x0100).to_bytes(2, "big") + b"\x00" * 10
        + (0x00010000).to_bytes(4, "big") + (0).to_bytes(4, "big") * 2
        + (0).to_bytes(4, "big") + (0x00010000).to_bytes(4, "big") + (0).to_bytes(4, "big")
        + (0).to_bytes(4, "big") * 2 + (0x40000000).to_bytes(4, "big")
        + b"\x00" * 24 + (1).to_bytes(4, "big"))
moov = box(b"moov", box(b"mvhd", mvhd))
mdat = box(b"mdat", bytes(2048))
w("probe.mp4", ftyp + free + moov + mdat)
# 16 .zip
with zipfile.ZipFile(os.path.join(D, "probe.zip"), "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("probe_inner.txt", f"PROBE zip OK\n{TS}\n")
# 17 .tar.gz
inner = f"PROBE targz OK\n{TS}\n".encode()
with tarfile.open(os.path.join(D, "probe.tar.gz"), "w:gz") as t:
    ti = tarfile.TarInfo("probe_inner.txt"); ti.size = len(inner)
    t.addfile(ti, io.BytesIO(inner))
# 18 .rtf
w("probe.rtf", "{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Courier;}}\\f0\\fs20 PROBE rtf OK\\par " + TS + "\\par}\n")
# 19 .bin
w("probe.bin", f"PROBE bin OK\n{TS}\n".encode() + bytes(range(256)) * 4)
# 20 .ipynb
nb = {"nbformat": 4, "nbformat_minor": 5, "metadata": {},
      "cells": [
          {"cell_type": "markdown", "metadata": {}, "source": [f"PROBE ipynb OK\n", TS]},
          {"cell_type": "code", "metadata": {}, "execution_count": None,
           "outputs": [], "source": [f"print('PROBE ipynb OK {TS}')"]}] }
w("probe.ipynb", json.dumps(nb, indent=2) + "\n")
# 21 .yaml
w("probe.yaml", f"probe: PROBE yaml OK\nts: '{TS}'\nitems: [1, 2, 3]\n")
# 22 .log
w("probe.log", f"{TS} INFO  PROBE log OK - viewer calibration probe\n{TS} INFO  second log line\n")

# Controls
zbytes = open(os.path.join(D, "probe.zip"), "rb").read()
w("control_ziphead.txt", zbytes[:300])                       # C01: zip head as .txt
w("control_empty.md", "")                                    # C02: 0-byte .md
w("control_empty.zip", b"")                                  # C03: 0-byte .zip
w("control caf\u00e9 space.md", f"# PROBE md-space-unicode OK\n\n{TS}\n\nFilename has a space and non-ASCII char.\n")  # C04
line = f"PROBE md-big OK {TS} " + "x" * 60 + "\n"            # C05: ~10 MB .md
n = (10 * 1024 * 1024) // len(line)
w("control_big10mb.md", line * n)
w("control_cdn.html", f"<!DOCTYPE html>\n<html><head><meta charset=\"utf-8\"><title>cdn probe</title>\n<link rel=\"stylesheet\" href=\"https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css\">\n</head>\n<body><h1>PROBE html-cdn OK</h1><p>{TS}</p><p>CDN stylesheet row: unstyled render still counts as preview.</p></body></html>\n")  # C06

print("generated OK")
