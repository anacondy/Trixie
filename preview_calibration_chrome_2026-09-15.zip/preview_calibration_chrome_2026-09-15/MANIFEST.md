# Preview calibration bundle — Chrome run

- Browser: Chrome. Probe Step-0 utc: Tue Sep 15 16:30:47 UTC 2026. Bundle built: Tue Sep 15 17:53:39 UTC 2026. Session: unknown.
- Agent role: handoff runner (file generation + `present_file` handoff). All P/D/E verdicts are human-observed votes collected in an interactive 29-row walkthrough.

## Environment (reproducibility)
- Python 3.13.14
- uname: Linux e2b.local 6.1.158+ #1 SMP PREEMPT_DYNAMIC Fri Jul 17 14:31:34 UTC 2026 x86_64 GNU/Linux
- file: file-5.46
- Python packages: pillow=12.3.0, python-docx=1.1.2, openpyxl=3.1.5, python-pptx=1.0.2
- No ffmpeg available: PDF/MP3/MP4 are hand-built minimal-but-valid binaries (real PDF xref, ID3v2.3 + MPEG frame syncs, ISO-BMFF ftyp/moov/mdat). EXE is a real minimal MS-DOS MZ executable (header + working int21h code), verified by `file` as `MS-DOS executable, MZ for MS-DOS`.

## Reproduce the probe pack
```
python3 make_probes.py          # 22 standard probes + 6 controls (Step-0 ts Tue Sep 15 16:30:47 UTC 2026)
python3 make_extra_probes.py    # probe.exe + "notes ✓.md"
cd preview_probe && sha256sum -c checksums.txt
```

## Verify this bundle
```
unzip preview_calibration_chrome_2026-09-15.zip
cd preview_calibration_chrome_2026-09-15 && sha256sum -c SHA256SUMS
```
(SHA256SUMS covers every bundled file. The zip's own SHA-256 is printed by the bundling run and recorded below at build time.)

## Human verdicts (Chrome, rows 1-29)
P P P P P P P P P P P P P P P D D P D D P P P P P D P E P
P=23 (md txt html py json csv png svg pdf docx xlsx pptx jpg mp3 mp4 rtf ipynb yaml log zip-as-txt empty-md notes✓ cdn-html),
D=5 (zip targz exe bin empty-zip), E=1 (10MB md broke chat loading; retry later).
Full table: preview_results.md. Raw votes: verdicts.txt.

## Inventory (path | bytes | sha256)
| path | bytes | sha256 |
|---|---|---|
| `preview_calibration_chrome_2026-09-15/checksums.txt` | 2435 | `15534b8e8435233b96751a23a3083798c918230c61101feefadcb6ef9f9b8554` |
| `preview_calibration_chrome_2026-09-15/make_extra_probes.py` | 906 | `4abdfa08838a63534b2fba56f55795e40ece28ec3eb70d9522c69982462c51cb` |
| `preview_calibration_chrome_2026-09-15/make_probes.py` | 7126 | `338b64ac33d628db78a574fcafe665376a5789ee9dab1efa33ebb5ec79409b5e` |
| `preview_calibration_chrome_2026-09-15/preview_results.md` | 1718 | `ec0bd2e24b8bd1335de668b5dd03205df19f4457d13c537c4c4449076c01f141` |
| `preview_calibration_chrome_2026-09-15/probes/control café space.md` | 100 | `28cad2f95b09d58abce14daf636fbb353fca5ae0149877fe263af171ba505067` |
| `preview_calibration_chrome_2026-09-15/probes/control_big10mb.md` | 10485732 | `dcea7d40036a90726d31c728b3a0f574164338b41eba256587792a62ac598799` |
| `preview_calibration_chrome_2026-09-15/probes/control_cdn.html` | 336 | `bbec396e066f3a9f88c8e4307790ee1a25f705e42919f232981857786dd3b884` |
| `preview_calibration_chrome_2026-09-15/probes/control_empty.md` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `preview_calibration_chrome_2026-09-15/probes/control_empty.zip` | 0 | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `preview_calibration_chrome_2026-09-15/probes/control_ziphead.txt` | 172 | `b1a8d307b6925783737492dfbfb0cd4f202eec3adbdad5b80a6d49913bc95f54` |
| `preview_calibration_chrome_2026-09-15/probes/notes ✓.md` | 102 | `7c4a72aae8b8975679d89581999e18da8ebd120531db7bc524f82b36659ec1b2` |
| `preview_calibration_chrome_2026-09-15/probes/probe.bin` | 1066 | `b8b726eff123858a7f81904d55200da383be57b3d6f5a3541d1a68d8bf0a5293` |
| `preview_calibration_chrome_2026-09-15/probes/probe.csv` | 100 | `f587e2649a09285082a135ba49c0a35197602f82d1d0d9a5bca0b49a5909c1ba` |
| `preview_calibration_chrome_2026-09-15/probes/probe.docx` | 36671 | `4b126b2ab3d8ddb33de7de8dde02976ab149fa7cf615685dd1b51a51bd53344c` |
| `preview_calibration_chrome_2026-09-15/probes/probe.exe` | 120 | `ddbf9db6b9ff0e132ece2c487ef93b6e75f5d10d4436b3ab0a6f97ce14038bc3` |
| `preview_calibration_chrome_2026-09-15/probes/probe.html` | 156 | `ac4d2f149db41e9d9d00b12388bcaab526010ea47d31ac07cfb5d8f1e4a9bd64` |
| `preview_calibration_chrome_2026-09-15/probes/probe.ipynb` | 440 | `2290ed6366b885a21ea3a432235d493d45e1c08174ee77d9ef96c715f655a747` |
| `preview_calibration_chrome_2026-09-15/probes/probe.jpg` | 12054 | `0721e594499ee2c77bc817eb879ff1be334c633f3da91dc6c8844a1ab57b6dc6` |
| `preview_calibration_chrome_2026-09-15/probes/probe.json` | 71 | `9c7fc2ebf910ae37c2fe5ce980db7c9c718087af9de8af24620e5918d890d782` |
| `preview_calibration_chrome_2026-09-15/probes/probe.log` | 126 | `b7f797e02fc04a4ceba751fee55d1d3bcbc2f5a94c9931c0f0da531c4eef25fc` |
| `preview_calibration_chrome_2026-09-15/probes/probe.md` | 93 | `2f811a2445fcf57507085c53b4de08eacf882b7e7e4a72097056ba16ce7d353b` |
| `preview_calibration_chrome_2026-09-15/probes/probe.mp3` | 13406 | `166f52d37f5ff80571f426b6b0f04fa4e8606fdccf1aac933535b4ab4023e2b8` |
| `preview_calibration_chrome_2026-09-15/probes/probe.mp4` | 2249 | `6892a00f58634cdc52218e85cbb3201e89930e03bfa5ec75ee6185b899f4fabe` |
| `preview_calibration_chrome_2026-09-15/probes/probe.pdf` | 646 | `20a2b2390f5a29482e19203f3e3ca29ae1833e9b9d11178b5e73e51d8481b48d` |
| `preview_calibration_chrome_2026-09-15/probes/probe.png` | 4720 | `abb1f426dd79d9b44bb4e5946944e95b8b0cf73a577eb011e4e42a2d32388f86` |
| `preview_calibration_chrome_2026-09-15/probes/probe.pptx` | 28303 | `d9cffd5161d125bbfe6610d58a3799aa612a1ee2895e0fd4db4b18009b526840` |
| `preview_calibration_chrome_2026-09-15/probes/probe.py` | 151 | `27e658a58ebd4ac31331e87db5c4b1240c833ce336bdc8888670a65efa179027` |
| `preview_calibration_chrome_2026-09-15/probes/probe.rtf` | 101 | `dceb6fe88334e142b4437066aad0ee1c72154c23e284c1413695df41c6b9dfe9` |
| `preview_calibration_chrome_2026-09-15/probes/probe.svg` | 289 | `2bf97abee3af3d142e674c30c3486cc1c6d1f005056c448dde2b8f8744406235` |
| `preview_calibration_chrome_2026-09-15/probes/probe.tar.gz` | 163 | `aa54fd225b7c7b44437984d874663c474ef44370b5f1949020778b79b0e492e2` |
| `preview_calibration_chrome_2026-09-15/probes/probe.txt` | 92 | `65d9ac38a3c251d07e812fb1b3ec88d9a059eb14e63e74d5e1eb4f4706565d84` |
| `preview_calibration_chrome_2026-09-15/probes/probe.xlsx` | 4869 | `72e0068b5eddcec6d73785bd616fc852c548d94b0a583b01d14ae13fa0a1fddd` |
| `preview_calibration_chrome_2026-09-15/probes/probe.yaml` | 73 | `b8cccdec8b622d09bb321133ca532f56096b2f60cc34394ca4e61452ef48dbd1` |
| `preview_calibration_chrome_2026-09-15/probes/probe.zip` | 172 | `b1a8d307b6925783737492dfbfb0cd4f202eec3adbdad5b80a6d49913bc95f54` |
| `preview_calibration_chrome_2026-09-15/reference_preview_master_sheet.md` | 2606 | `6f19a77aa362e4e8cb760558f2bb51c56aa2b78a32fa9b2ae30b65ef2fb6a4e9` |
| `preview_calibration_chrome_2026-09-15/verdicts.txt` | 175 | `ec170bda3583a32b8b3a7b0d45e59d3c7db66c33434ace06a106eaaecbc8754d` |
