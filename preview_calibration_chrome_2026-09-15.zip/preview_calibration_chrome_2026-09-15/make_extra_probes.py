#!/usr/bin/env python3
"""Supplement to make_probes.py: row 19 (probe.exe, minimal valid MS-DOS MZ
executable that prints the PROBE line via DOS int 21h/AH=09 and exits via
int 21h/AX=4C00) and row 27 (notes checkmark .md). Same Step-0 timestamp."""
import struct
TS = "Tue Sep 15 16:30:47 UTC 2026"
D = "/home/user/preview_probe"
msg = ("PROBE exe OK " + TS).encode() + b"\r\n$"
code = bytes([0xB4,0x09, 0xBA,0x4C,0x01, 0xCD,0x21, 0xB8,0x00,0x4C, 0xCD,0x21])
assert len(code) == 12
size = 64 + len(code) + len(msg)
hdr = struct.pack("<2s13H8sHH20sI", b"MZ", size % 512 or 512, (size+511)//512,
    0, 4, 0, 0xFFFF, 0, 0x0200, 0, 0, 0, 0x40, 0, b"\0"*8, 0, 0, b"\0"*20, 0)
assert len(hdr) == 64
open(f"{D}/probe.exe", "wb").write(hdr + code + msg)
open(f"{D}/notes \u2713.md", "w").write(
    f"# PROBE md-unicode-name OK\n\n{TS}\n\nFilename has a space and U+2713 CHECK MARK.\n")
print("extra probes ok")
