# Master verdict sheet — Arena in-app viewer (2026-09-14)

Consolidated from the three browser runs (uploads: `Pre View Chrome results.md`, `Pre View Edge results.md`, `Pre View Brave results.md`) plus the prompt-gen session screenshots. Agent side proved **handoff only** (`present_file` → `{"status":"success",...}` for every probe in all runs); rendering is human-only. Fill one letter per browser: **P** preview / **D** download-only / **E** error. Per-run bytes+sha256 live in each run's own `checksums.txt`/table (probes were generated independently per run — sizes/hashes differ by design; verify downloads with `sha256sum -c` against the matching run's checksums).

| # | type / control | spec-expected | Chrome | Edge | Brave | what this row decides |
|---|---|---|---|---|---|---|
| 1 | `.md` | P | | | | claimed previewable; self-test (this sheet rendering = P) |
| 2 | `.txt` | P | | | | claimed |
| 3 | `.html` | P | | | | claimed |
| 4 | `.py` | P | | | | code |
| 5 | `.json` | P (text/code) | | | | text-vs-other routing |
| 6 | `.csv` | P | | | | claimed |
| 7 | `.png` | P | | | | image |
| 8 | `.svg` | P | | | | spec-only type |
| 9 | `.pdf` | P | | | | spec-only |
| 10 | `.docx` | P | | | | Office |
| 11 | `.xlsx` | P | | | | Office |
| 12 | `.pptx` | P | | | | Office |
| 13 | `.jpg` | P | | | | image |
| 14 | `.mp3` | P | | | | audio |
| 15 | `.mp4` | P | | | | video |
| 16 | `.zip` | D | | | | suspected download-only |
| 17 | `.tar.gz` | D | | | | suspected |
| 18 | `.rtf` | D | | | | legacy text-ish |
| 19 | `.exe` | D | | | | binary |
| 20 | `.bin` | D | | | | octet-stream |
| 21 | `.ipynb` | D?/P? | | | | notebook-vs-JSON routing |
| 22 | `.yaml` | D?/P? | | | | text routing |
| 23 | `.log` | D?/P? | | | | text routing |
| 24 | zip-bytes as `.txt` | P vs D | | | | **extension routing vs content sniffing** |
| 25 | 0-byte `.md` | P?/E? | | | | empty-file UX |
| 26 | 0-byte `.zip` | D?/E? | | | | empty+invalid |
| 27 | `notes ✓.md` | P | | | | spaces + U+2713 in name |
| 28 | ~10 MiB `.md` | P(trunc?)/E | | | | size truncation/refusal |
| 29 | `.html` + CDN css | P unstyled | | | | sandboxed iframe no-network degrade |

Already human-observed (from your screenshots, not the agent): `.md` = P (results.md, this sheet, and timekeeper ARCHITECTURE.md all render as MD cards in-app), `.png` = P (attachments render), `.c`/`.h` code = P (timeutil.h, sntp_proto.c, fallback_proto.c rendered as PLAIN code cards with the Open button, timekeeper session 01a0a170). Everything else awaits your three columns; browser-disagreement in any row is itself a finding.
