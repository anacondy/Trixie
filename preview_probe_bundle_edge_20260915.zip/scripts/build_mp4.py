#!/usr/bin/env python3
"""Build preview_probe/probe_mp4.mp4 with a real encoder.
Encoder: libx264 bundled with imageio-ffmpeg (pip install imageio-ffmpeg).
Frame text is rasterized by Pillow first (the bundled ffmpeg has no drawtext
filter), then looped into a 2 s 320x240 10fps yuv420p video, +faststart."""
import imageio_ffmpeg, subprocess, os
from PIL import Image, ImageDraw

TS = "Tue Sep 15 16:32:24 UTC 2026"          # Step-0 header timestamp of the run
ff = imageio_ffmpeg.get_ffmpeg_exe()
src = "/tmp/probe_frame.png"
img = Image.new("RGB", (320, 240), "#0b3d91")
d = ImageDraw.Draw(img)
d.text((20, 90), "PROBE mp4 OK", fill="white")
d.text((20, 150), TS, fill="#cfe0ff")
img.save(src)
out = "/home/user/preview_probe/probe_mp4.mp4"
r = subprocess.run([ff, "-y", "-loop", "1", "-i", src, "-t", "2", "-r", "10",
    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-metadata", "comment=" + TS,
    "-movflags", "+faststart", out], capture_output=True, text=True, timeout=120)
assert r.returncode == 0, r.stderr[-600:]
print("wrote", out, os.path.getsize(out), "bytes")
