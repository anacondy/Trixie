#!/usr/bin/env python3
"""Build preview_probe/probe_mp3.mp3 with a real encoder.
Encoder: libmp3lame bundled with imageio-ffmpeg (pip install imageio-ffmpeg).
Content: 2 s of stereo silence at 44.1 kHz, 64 kbps (anullsrc) — silent by design;
probe marker lives in ID3 metadata (title/comment)."""
import imageio_ffmpeg, subprocess, os

TS = "Tue Sep 15 16:32:24 UTC 2026"          # Step-0 header timestamp of the run
ff = imageio_ffmpeg.get_ffmpeg_exe()
out = "/home/user/preview_probe/probe_mp3.mp3"
r = subprocess.run([ff, "-y", "-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo",
    "-t", "2", "-c:a", "libmp3lame", "-b:a", "64k",
    "-metadata", "title=PROBE mp3 OK", "-metadata", "comment=" + TS,
    out], capture_output=True, text=True, timeout=120)
assert r.returncode == 0, r.stderr[-600:]
print("wrote", out, os.path.getsize(out), "bytes")
