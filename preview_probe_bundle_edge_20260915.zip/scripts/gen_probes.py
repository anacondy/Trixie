#!/usr/bin/env python3
"""Generate the standard preview-probe pack in preview_probe/."""
import json, os, struct, tarfile, zipfile, io, hashlib
from PIL import Image, ImageDraw, PngImagePlugin
import docx, openpyxl, pptx
from pptx.util import Inches

TS = "Tue Sep 15 16:32:24 UTC 2026"
ROOT = "/home/user/preview_probe"
os.makedirs(ROOT, exist_ok=True)

def probe(ext):
    return f"PROBE {ext} OK"

def w(name, data):
    p = os.path.join(ROOT, name)
    mode = "wb" if isinstance(data, (bytes, bytearray)) else "w"
    with open(p, mode, encoding="utf-8" if mode == "w" else None) as f:
        f.write(data)
    return p

# ---------- text-family probes ----------
w("probe_md.md", f"# Probe\n\n{probe('md')} {TS}\n")
w("probe_txt.txt", f"{probe('txt')} {TS}\n")
w("probe_html.html",
  f"<!DOCTYPE html>\n<html><head><meta charset='utf-8'><title>Probe HTML</title></head>\n"
  f"<body><h1>{probe('html')}</h1><p>{TS}</p></body></html>\n")
w("probe_py.py", f'#!/usr/bin/env python3\n# {probe("py")} {TS}\nprint("{probe("py")} {TS}")\n')
w("probe_json.json", json.dumps({"probe": probe("json"), "timestamp": TS}, indent=2) + "\n")
w("probe_csv.csv", f"probe,status,timestamp\n{probe('csv')},OK,{TS}\n")
w("probe_svg.svg",
  f"<svg xmlns='http://www.w3.org/2000/svg' width='420' height='120'>"
  f"<rect width='100%' height='100%' fill='#0b3d91'/>"
  f"<text x='16' y='52' font-family='monospace' font-size='22' fill='white'>{probe('svg')}</text>"
  f"<text x='16' y='84' font-family='monospace' font-size='14' fill='#cfe0ff'>{TS}</text></svg>\n")
w("probe_rtf.rtf", "{\\rtf1\\ansi\\deff0 {\\fonttbl{\\f0 Courier New;}}\\f0\\fs24 "
  + probe("rtf") + "\\line " + TS + "\\par}\n")
w("probe_yaml.yaml", f'probe: "{probe("yaml")}"\ntimestamp: "{TS}"\n')
w("probe_log.log", f"[INFO] {TS} {probe('log')}\n[INFO] second line\n[INFO] third line\n")
w("probe_bin.bin", (probe("bin") + " " + TS + "\n").encode() + bytes(range(256)) * 4)
w("probe_ipynb.ipynb", json.dumps({
    "cells": [{"cell_type": "markdown", "metadata": {},
               "source": [f"# {probe('ipynb')}\n", f"{TS}\n"]},
              {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [],
               "source": [f'print("{probe("ipynb")} {TS}")']}],
    "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python",
                                "name": "python3"},
                 "language_info": {"name": "python", "version": "3.13"}},
    "nbformat": 4, "nbformat_minor": 5}, indent=1) + "\n")

# ---------- png / jpg via Pillow ----------
img = Image.new("RGB", (480, 140), "#0b3d91")
d = ImageDraw.Draw(img)
d.text((14, 40), probe("png"), fill="white")
d.text((14, 90), TS, fill="#cfe0ff")
meta = PngImagePlugin.PngInfo()
meta.add_text("probe", probe("png") + " " + TS)
img.save(os.path.join(ROOT, "probe_png.png"), pnginfo=meta)
img2 = Image.new("RGB", (480, 140), "#7a0b91")
d2 = ImageDraw.Draw(img2)
d2.text((14, 40), probe("jpg"), fill="white")
d2.text((14, 90), TS, fill="#f0cfff")
img2.save(os.path.join(ROOT, "probe_jpg.jpg"), quality=90,
          exif=img2.getexif())  # baseline JPEG

# ---------- docx / xlsx / pptx ----------
doc = docx.Document()
doc.add_heading(probe("docx"), 0)
doc.add_paragraph(TS)
doc.save(os.path.join(ROOT, "probe_docx.docx"))

wb = openpyxl.Workbook()
ws = wb.active
ws["A1"] = probe("xlsx"); ws["A2"] = TS
wb.save(os.path.join(ROOT, "probe_xlsx.xlsx"))

prs = pptx.Presentation()
slide = prs.slides.add_slide(prs.slide_layouts[6])
tb = slide.shapes.add_textbox(Inches(1), Inches(1), Inches(8), Inches(2))
tb.text_frame.text = probe("pptx") + "\n" + TS
prs.save(os.path.join(ROOT, "probe_pptx.pptx"))

# ---------- pdf (hand-built minimal, correct xref offsets) ----------
content = f"BT /F1 24 Tf 72 720 Td ({probe('pdf')}) Tj 0 -30 Td /F1 14 Tf ({TS}) Tj ET".encode()
objs = []
objs.append(b"<< /Type /Catalog /Pages 2 0 R >>")
objs.append(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>")
objs.append(b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R "
            b"/Resources << /Font << /F1 5 0 R >> >> >>")
objs.append(b"<< /Length " + str(len(content)).encode() + b" >>\nstream\n" + content + b"\nendstream")
objs.append(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>")
pdf = bytearray(b"%PDF-1.4\n")
offsets = []
for i, body in enumerate(objs, 1):
    offsets.append(len(pdf))
    pdf += str(i).encode() + b" 0 obj\n" + body + b"\nendobj\n"
xref_at = len(pdf)
pdf += b"xref\n0 " + str(len(objs) + 1).encode() + b"\n0000000000 65535 f \n"
for off in offsets:
    pdf += ("%010d 00000 n \n" % off).encode()
pdf += (b"trailer\n<< /Size " + str(len(objs) + 1).encode() +
        b" /Root 1 0 R >>\nstartxref\n" + str(xref_at).encode() + b"\n%%EOF\n")
w("probe_pdf.pdf", bytes(pdf))

# ---------- mp3 (hand-built: ID3v2.3 + valid silent MPEG-1 Layer III frames) ----------
def id3v2(text):
    payload = b"TIT2\x00\x00\x00"  # frame header placeholder, sizes patched below
    body = text.encode("latin-1", "replace")
    frame = b"TIT2" + struct.pack(">I", len(body) + 1) + b"\x00\x00" + b"\x00" + body
    tag_body = frame
    size = len(tag_body)
    def syncsafe(n):
        return bytes([(n >> 21) & 0x7F, (n >> 14) & 0x7F, (n >> 7) & 0x7F, n & 0x7F])
    return b"ID3\x03\x00\x00" + syncsafe(size) + tag_body

def mp3_frames(n=10):
    # MPEG-1 Layer III, 128 kbps, 44.1 kHz, stereo, no CRC -> header FF FB 90 04
    header = bytes([0xFF, 0xFB, 0x90, 0x04])
    frame_len = 144 * 128000 // 44100  # 417 bytes, no padding
    return b"".join(header + bytes(frame_len - 4) for _ in range(n))

w("probe_mp3.mp3", id3v2(probe("mp3") + " " + TS) + mp3_frames())

# ---------- zip / tar.gz ----------
payload = (probe("zip") + " " + TS + "\n").encode()
zbuf = io.BytesIO()
with zipfile.ZipFile(zbuf, "w", zipfile.ZIP_DEFLATED) as zf:
    zf.writestr("probe.txt", payload.decode())
    zf.writestr("readme.md", f"# archive\n\n{probe('zip')} {TS}\n")
zip_bytes = zbuf.getvalue()
w("probe_zip.zip", zip_bytes)

tbuf = io.BytesIO()
with tarfile.open(fileobj=tbuf, mode="w:gz") as tf:
    ti = tarfile.TarInfo("probe.txt"); ti.size = len(payload)
    tf.addfile(ti, io.BytesIO(payload))
w("probe_tar.tar.gz", tbuf.getvalue())

# ---------- controls ----------
w("control_truncated_zip.txt", zip_bytes[:300])          # first 300 bytes of valid zip
w("control_empty.md", b"")                                # 0-byte .md
w("control_empty.zip", b"")                               # 0-byte .zip
w("control_probe ünïcødé spàce.md", f"{probe('md')} {TS} (filename: space + non-ASCII)\n")

# ~10 MB .md
target = 10_000_000
head = f"# 10 MB probe\n\n{probe('md')} {TS}\n\n"
line = "Filler line 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ\n"
reps = (target - len(head.encode())) // len(line)
w("control_10mb.md", head.encode() + line.encode() * reps)

w("control_cdn.html",
  "<!DOCTYPE html>\n<html><head><meta charset='utf-8'><title>CDN control</title>\n"
  "<link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/water.css@2/out/water.min.css'>\n"
  "</head>\n<body><h1>CDN stylesheet control</h1>"
  f"<p>{probe('html')} {TS}</p><p>Expect graceful unstyled degrade in-app.</p></body></html>\n")

print("generated files:")
for f in sorted(os.listdir(ROOT)):
    print(" ", f, os.path.getsize(os.path.join(ROOT, f)))
