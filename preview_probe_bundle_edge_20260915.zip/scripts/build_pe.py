#!/usr/bin/env python3
"""Hand-build preview_probe/probe_exe.exe — a minimal but structurally real
PE32 console executable (i386), NOT a rename. Verified with `file` as:
  PE32 executable for MS Windows 4.00 (console), Intel i386, 2 sections
Layout (FileAlignment 0x200, SectionAlignment 0x1000, ImageBase 0x400000):
  0x000 DOS header (e_lfanew=0x40)
  0x040 PE\\0\\0 + COFF header + PE32 optional header (96 B) + 16 data dirs (128 B)
  0x138 section headers: .text (r-x), .rdata (rw)
  0x200 .text:  push 0 ; call [IAT:ExitProcess] ; ret
  0x400 .rdata: import descriptor -> kernel32.dll!ExitProcess (by name),
                ILT, hint/name, DLL name, IAT, plus "PROBE exe OK <ts>" marker.
Total 1536 bytes. Runtime untested (no Windows in the build sandbox);
structure verified by file(1) MIME application/vnd.microsoft.portable-executable."""
import struct, os

TS = "Tue Sep 15 16:32:24 UTC 2026"          # Step-0 header timestamp of the run
IMAGE_BASE = 0x400000

rdata = bytearray(0x68)
def put(off, data): rdata[off:off+len(data)] = data
put(0x00, struct.pack("<IIIII", 0x2028, 0, 0, 0x2040, 0x2050))   # import descriptor
put(0x14, struct.pack("<IIIII", 0, 0, 0, 0, 0))                  # null descriptor
put(0x28, struct.pack("<II", 0x2030, 0))                         # ILT
put(0x30, struct.pack("<H", 0) + b"ExitProcess\x00")             # hint/name
put(0x40, b"kernel32.dll\x00")                                   # dll name
put(0x50, struct.pack("<II", 0x2030, 0))                         # IAT
put(0x58, ("PROBE exe OK " + TS + "\x00").encode())              # probe marker

IAT_RVA = 0x2050
code = bytes([0x6A, 0x00]) + b"\xFF\x15" + struct.pack("<I", IMAGE_BASE + IAT_RVA) + b"\xC3"

dos = bytearray(64); dos[0:2] = b"MZ"; struct.pack_into("<I", dos, 0x3C, 0x40)
coff = struct.pack("<HHIIIHH", 0x14C, 2, 0x68CF0000, 0, 0, 224, 0x102)
opt = struct.pack("<HBB" + "I"*9 + "H"*6 + "I"*4 + "H"*2 + "I"*6,
    0x10B, 1, 0,                       # magic PE32, linker 1.0
    0x200, 0x200, 0,                   # sizes of code / init data / uninit data
    0x1000, 0x1000, 0x2000,            # entry point, BaseOfCode, BaseOfData
    IMAGE_BASE, 0x1000, 0x200,         # image base, section align, file align
    4, 0, 0, 0, 4, 0,                  # OS/image/subsystem versions
    0, 0x3000, 0x200, 0,               # win32ver, SizeOfImage, SizeOfHeaders, checksum
    3, 0,                              # subsystem=console, DllCharacteristics
    0x100000, 0x1000, 0x100000, 0x1000, 0, 16)  # stack/heap, loader flags, ndirs
assert len(opt) == 96                  # +128 data dirs = SizeOfOptionalHeader 224

dd = bytearray(128)
struct.pack_into("<II", dd, 8, 0x2000, 0x28)   # DataDirectory[1] = imports
sec_text  = b".text\x00\x00\x00" + struct.pack("<IIIIIIHHI", 8, 0x1000, 0x200, 0x200, 0,0,0,0, 0x60000020)
sec_rdata = b".rdata\x00\x00" + struct.pack("<IIIIIIHHI", len(rdata), 0x2000, 0x200, 0x400, 0,0,0,0, 0xC0000040)

img = bytearray(0x600)
img[0:64] = dos
img[0x40:0x44] = b"PE\x00\x00"
img[0x44:0x44+len(coff)] = coff
img[0x58:0x58+len(opt)] = opt
img[0x58+96:0x58+96+128] = dd
img[0x138:0x138+40] = sec_text
img[0x160:0x160+40] = sec_rdata
img[0x200:0x200+len(code)] = code
img[0x400:0x400+len(rdata)] = rdata

p = "/home/user/preview_probe/probe_exe.exe"
open(p, "wb").write(bytes(img))
print("wrote", p, os.path.getsize(p), "bytes")
