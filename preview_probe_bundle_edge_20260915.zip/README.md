# Preview-probe bundle (Edge run, 2026-09-15)
Start with METADATA.md (identity, inventory, reproduction, determinism notes).
Verdicts: results/results_edge_2026-09-15.md. Checksums: MANIFEST.sha256/.sha1/.md5.
