# METADATA — Arena in-app viewer probe bundle (Edge run)

## Identity
- run_header: browser=Edge session=unknown utc=Tue Sep 15 16:32:24 UTC 2026
- bundle_built_utc: Tue Sep 15 17:54:45 UTC 2026 (see environment.txt)
- purpose: let a human calibrate what the Arena/LMarena in-app viewer previews (P)
  vs downloads (D) vs errors (E), per file extension + edge-case controls.
- epistemics: agent proved HANDOFF ONLY (present_file -> {"status":"success"});
  every P/D/E verdict below was supplied by the human via interactive prompts.
  No rendering was observed or claimed by the agent at any point.

## Layout
- probes/       29 probe+control files (the presented artifacts, incl. probe_exe.exe)
- probes/checksums.txt   sha256 manifest generated at build time (sha256sum *)
- results/      results_edge_2026-09-15.md — filled verdict sheet + findings
- scripts/      exact generators used (see Reproduction)
- inputs/       preview_master_sheet.md — the orchestrator's 29-row sheet (user upload)
- environment.txt        tool/OS fingerprint of the build sandbox
- MANIFEST.sha256 / .sha1 / .md5   checksums of every file in this bundle
- README.md     short pointer file

## Probe inventory (freshly recomputed at bundle time)
n | file | bytes | sha256 | edge_verdict

01 | control_10mb.md | 9999970 | e1c43c9391e9dcf2165dff54ea0ec6e165ece22cc47a8facf5725f0fd40ba8f9 | DEFERRED(chat-load error on present; retry pending)
02 | control_cdn.html | 323 | d7a9432a58c7b024cf896a735908ce2fbd767dc348506f199c018bf0225ca115 | P(unstyled ok)
03 | control_empty.md | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | P(empty card)
04 | control_empty.zip | 0 | e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855 | D
05 | control_probe ünïcødé spàce.md | 71 | 2e2d00d75740288496bdd14ea1463a6cc305d285058836d1919bbb706b4d2535 | P
06 | control_truncated_zip.txt | 300 | d1b5234b44b2f619503d8b6943086f61ddca8fba544e5270e31072436693f7b9 | P
07 | probe_bin.bin | 1066 | 3411c14cad219fcf9038b5096f813963242bb32ca76ed89b246dff42b3589516 | D
08 | probe_csv.csv | 68 | fa94661bc268725dafcd69b35a37b824b75695e857d3f9aeabb6b8028e82072f | P
09 | probe_docx.docx | 36640 | 0e38dc8520486b074839b486db5630a7e9ac4d0369a09882abf03df49c4bdeb8 | P
10 | probe_exe.exe | 1536 | ac7684283683c699281308a47e3b5c1943d5c691e6341f300153aeebe8146175 | D
11 | probe_html.html | 161 | 9eb0a5b05bb2ecb1db4366f0ca5967b29fca9c062c41b7e7581e288b8acc6f72 | P
12 | probe_ipynb.ipynb | 560 | 1a797168b52ed38de37828865ec98b371cb81b464fc256627e3a718cb8a5eafa | P(json/code)
13 | probe_jpg.jpg | 4389 | 0bf3db62dc8a8ea7ee68a697a12a33caca1c7f4730eab0eade1ded0a23d11d5e | P
14 | probe_json.json | 78 | 07d84c865f6582c0519e5f4a2049eec67145a230bcd91dfc9bb83272411babd8 | P
15 | probe_log.log | 86 | a7341a4b7da0b9263cebb83e74ec650ceb5b16f1541c21df3299f52f251ef1ae | P
16 | probe_md.md | 50 | 4c9b70e857cf961961da6f577425616d09faf2fe1d01a4603820f43f453198a0 | P
17 | probe_mp3.mp3 | 16624 | 6397aa95477910f03ed5ee9c41a4df945e6e9d7852f2df8385959914fdd842ba | P
18 | probe_mp4.mp4 | 3758 | c98aedc3367c99c8b196164bc71f2d52aebed8b35f0ebe1ff3b5f729f98740d7 | P
19 | probe_pdf.pdf | 640 | 933f3128cc7df5017c0fe42c8f31ffaf34431a465bcf92d13c31c31e7b3730dd | P
20 | probe_png.png | 3402 | 5327f058c7c8c9b219ddfa78a92dc13ab0dc55ea2f233b09e82aa2788f6038db | P
21 | probe_pptx.pptx | 28303 | e97ea71f4e99166cc157f906918ee1e833298cbc3bbc520179d97c82544b1d89 | P
22 | probe_py.py | 116 | 05b6aa62615dbc44388d47a18e68ff2de109e3876794cec89bc39c809cfea53b | P
23 | probe_rtf.rtf | 107 | 3756fec91f2b0d309ea008ab22c96e8272a19ea6bd9f60168814f961c19a6adb | P
24 | probe_svg.svg | 321 | 462cd37b98f51333cea17aed21c345a7290f90dc09d8e5dc8db222548fa643bc | P
25 | probe_tar.tar.gz | 144 | 94e4fa9683f775420b5c17fa3dcdd19e61749fbdd2fb96940309e9076a724739 | D
26 | probe_txt.txt | 42 | 430dd152743a321b0f363fb8c958e0047613f27f06824259d0b78b223d99d86a | P
27 | probe_xlsx.xlsx | 4867 | ac736c103bbb505cdc9ba4c94f3137596a7b8cdce4e89b415fa4e8d4f2a6be6f | P
28 | probe_yaml.yaml | 65 | 3f359ebb06695807763a665d720969fb0e35524f6d40d5755e0451840b46153f | P
29 | probe_zip.zip | 309 | 819d317cd5f5d64e68ace00e3622ecb2d15ac03f9f72a82bc3ab6b4908fe653c | D
30 | results_edge_2026-09-15.md | 3532 | abd70f4578cfc1c772a347b029a674b0581f37879d1bdbac43b96600bd367788 | -

MIME types (file-5.46) and sha1/md5 are in the per-file MANIFEST.* files and in
the full table below.

### Full digest table (sha256 / sha1 / md5 / mime)

01 control_10mb.md
   sha256 e1c43c9391e9dcf2165dff54ea0ec6e165ece22cc47a8facf5725f0fd40ba8f9
   sha1   88d4ba20d61d31abb35887cdb222cfe9f6281270
   md5    7574eb720d5b8159693698abbfd95a43
   mime   text/plain  bytes=9999970
02 control_cdn.html
   sha256 d7a9432a58c7b024cf896a735908ce2fbd767dc348506f199c018bf0225ca115
   sha1   2b282b95db7454a8220f0ed03e97526b3457d7bd
   md5    8072d77d919e5ca538759a4178d8fd9d
   mime   text/html  bytes=323
03 control_empty.md
   sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
   sha1   da39a3ee5e6b4b0d3255bfef95601890afd80709
   md5    d41d8cd98f00b204e9800998ecf8427e
   mime   inode/x-empty  bytes=0
04 control_empty.zip
   sha256 e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
   sha1   da39a3ee5e6b4b0d3255bfef95601890afd80709
   md5    d41d8cd98f00b204e9800998ecf8427e
   mime   inode/x-empty  bytes=0
05 control_probe ünïcødé spàce.md
   sha256 2e2d00d75740288496bdd14ea1463a6cc305d285058836d1919bbb706b4d2535
   sha1   cb73949cc2b33751b2f61aaf8db97a0e93c89cb6
   md5    7ea8663f2733588e0997e98f539a5b0b
   mime   text/plain  bytes=71
06 control_truncated_zip.txt
   sha256 d1b5234b44b2f619503d8b6943086f61ddca8fba544e5270e31072436693f7b9
   sha1   4f7cbab935f60679ee6013ad9d2bddf75f787095
   md5    5be2db357107a8af9089a7f2d8ed9323
   mime   application/zip  bytes=300
07 probe_bin.bin
   sha256 3411c14cad219fcf9038b5096f813963242bb32ca76ed89b246dff42b3589516
   sha1   55475bbefd7e151259c702a94e355dfd71f5c3e5
   md5    df8e489721c09e4c56439052f75f6b65
   mime   application/octet-stream  bytes=1066
08 probe_csv.csv
   sha256 fa94661bc268725dafcd69b35a37b824b75695e857d3f9aeabb6b8028e82072f
   sha1   89f4b4a4f91da15f46fc964504957c16b2815297
   md5    2960b9a4b9eeb38ec6671aeecaea34b7
   mime   text/csv  bytes=68
09 probe_docx.docx
   sha256 0e38dc8520486b074839b486db5630a7e9ac4d0369a09882abf03df49c4bdeb8
   sha1   d40ab21d60768f2ef197112fe6aadfaf886bd534
   md5    27f169d58483204628ad4f85b64b5d2a
   mime   application/vnd.openxmlformats-officedocument.wordprocessingml.document  bytes=36640
10 probe_exe.exe
   sha256 ac7684283683c699281308a47e3b5c1943d5c691e6341f300153aeebe8146175
   sha1   7c30f2a914a97b65af8607bc82692cec1cda3d84
   md5    d94581ddccdff75f086ddabd5458b71b
   mime   application/vnd.microsoft.portable-executable  bytes=1536
11 probe_html.html
   sha256 9eb0a5b05bb2ecb1db4366f0ca5967b29fca9c062c41b7e7581e288b8acc6f72
   sha1   aa6d44fcd8422a2a1ec193b16dd9810745b04e8d
   md5    cf2d1cd1fb785faecc90c27626ce33dd
   mime   text/html  bytes=161
12 probe_ipynb.ipynb
   sha256 1a797168b52ed38de37828865ec98b371cb81b464fc256627e3a718cb8a5eafa
   sha1   5fca49fc81a5690c3bb61a0439f119e96db6cf4b
   md5    b2527964e7dde2244461e70eb7bfb650
   mime   application/json  bytes=560
13 probe_jpg.jpg
   sha256 0bf3db62dc8a8ea7ee68a697a12a33caca1c7f4730eab0eade1ded0a23d11d5e
   sha1   e40a263a9d62b92ddebc9fbfc4bf2466daab8cc9
   md5    19c09c1064281032af945119575391b2
   mime   image/jpeg  bytes=4389
14 probe_json.json
   sha256 07d84c865f6582c0519e5f4a2049eec67145a230bcd91dfc9bb83272411babd8
   sha1   32514e17a1e179113d09f2dc6b15eca2020afde7
   md5    45f6b6caef4128dd8caa48efccab44cd
   mime   application/json  bytes=78
15 probe_log.log
   sha256 a7341a4b7da0b9263cebb83e74ec650ceb5b16f1541c21df3299f52f251ef1ae
   sha1   e69dd7eb1a785bc1015039010653c64f7062d8fb
   md5    e3dcc8970d5e601fcde96765c4a96ad2
   mime   text/plain  bytes=86
16 probe_md.md
   sha256 4c9b70e857cf961961da6f577425616d09faf2fe1d01a4603820f43f453198a0
   sha1   dd30653021bdecb2f94b965debed28d71c967065
   md5    adc9bd25b65371ad9ca8a0d3172915fc
   mime   text/plain  bytes=50
17 probe_mp3.mp3
   sha256 6397aa95477910f03ed5ee9c41a4df945e6e9d7852f2df8385959914fdd842ba
   sha1   90a4de1d466e0822516e50d14ca85f5e53c510ef
   md5    0881f61d7380358b3f84d287fc8bfe0c
   mime   audio/mpeg  bytes=16624
18 probe_mp4.mp4
   sha256 c98aedc3367c99c8b196164bc71f2d52aebed8b35f0ebe1ff3b5f729f98740d7
   sha1   82a73bf8480cb635b715fbb911fde0daf7a2e676
   md5    9a1f8d8bea57c32e61299f9b6205f205
   mime   video/mp4  bytes=3758
19 probe_pdf.pdf
   sha256 933f3128cc7df5017c0fe42c8f31ffaf34431a465bcf92d13c31c31e7b3730dd
   sha1   ca83e0be4c9fae142564ba61cf9e6d060962908c
   md5    ecbc3541703ab156a814a4f61cc068b0
   mime   application/pdf  bytes=640
20 probe_png.png
   sha256 5327f058c7c8c9b219ddfa78a92dc13ab0dc55ea2f233b09e82aa2788f6038db
   sha1   1abea1d89400c89fd2c1685f2d5e376a83d53f02
   md5    235da296d9f5d4d6debe9acc572b673e
   mime   image/png  bytes=3402
21 probe_pptx.pptx
   sha256 e97ea71f4e99166cc157f906918ee1e833298cbc3bbc520179d97c82544b1d89
   sha1   0b995617542db46214d8eca17d304bb4c9bf1383
   md5    66d0d9efbabeecb888e3d35ab42c57d2
   mime   application/vnd.openxmlformats-officedocument.presentationml.presentation  bytes=28303
22 probe_py.py
   sha256 05b6aa62615dbc44388d47a18e68ff2de109e3876794cec89bc39c809cfea53b
   sha1   c1c00b53ba403bbf5c5226b696feb8eed817a17f
   md5    5c4856453899d19db8af38e540f4da06
   mime   text/x-script.python  bytes=116
23 probe_rtf.rtf
   sha256 3756fec91f2b0d309ea008ab22c96e8272a19ea6bd9f60168814f961c19a6adb
   sha1   b0f7973696c52223e38b606a89ea706942306644
   md5    47c523b5103dd7a6ae3064b912fcb266
   mime   text/rtf  bytes=107
24 probe_svg.svg
   sha256 462cd37b98f51333cea17aed21c345a7290f90dc09d8e5dc8db222548fa643bc
   sha1   63e0aa77c78325af2b6707ef7d76b01d3f5d8f0e
   md5    058e174e9ae42d0dfd2932a16cb59a2e
   mime   image/svg+xml  bytes=321
25 probe_tar.tar.gz
   sha256 94e4fa9683f775420b5c17fa3dcdd19e61749fbdd2fb96940309e9076a724739
   sha1   205b8428c66af033e8fe094e430dfb160ad42112
   md5    cb5ac9d27dd0aef6abf6d44890eb08c0
   mime   application/gzip  bytes=144
26 probe_txt.txt
   sha256 430dd152743a321b0f363fb8c958e0047613f27f06824259d0b78b223d99d86a
   sha1   c19ba4c67c77115d2a3b6002640fc76a8e2e87b2
   md5    3f85714048e0b7089bcfb6ac5089862b
   mime   text/plain  bytes=42
27 probe_xlsx.xlsx
   sha256 ac736c103bbb505cdc9ba4c94f3137596a7b8cdce4e89b415fa4e8d4f2a6be6f
   sha1   7ae6270f442c25fe85136797226cff87eb4cff51
   md5    4d21f16871fd7d7da750a283b3124b65
   mime   application/vnd.openxmlformats-officedocument.spreadsheetml.sheet  bytes=4867
28 probe_yaml.yaml
   sha256 3f359ebb06695807763a665d720969fb0e35524f6d40d5755e0451840b46153f
   sha1   566dea6bf170748560c043b964d2986bacb0000c
   md5    9a16dba3f4de2dcda26c61ecbcbf749d
   mime   text/plain  bytes=65
29 probe_zip.zip
   sha256 819d317cd5f5d64e68ace00e3622ecb2d15ac03f9f72a82bc3ab6b4908fe653c
   sha1   82d98b3ec53e7acea030049f98798a538f05c8b7
   md5    3c8deb3000fd490128715ab38f549536
   mime   application/zip  bytes=309
30 results_edge_2026-09-15.md
   sha256 abd70f4578cfc1c772a347b029a674b0581f37879d1bdbac43b96600bd367788
   sha1   0da75b37dd7f88f4cfa485af7a02464856073e18
   md5    5e1cce4c1f7d61a728d8795b79890630
   mime   text/plain  bytes=3532

## Reproduction
Environment (exact versions in environment.txt): Debian 13, Python 3.13.14,
pillow 12.3.0, python-docx 1.1.2, openpyxl 3.1.5, python-pptx 1.0.2,
imageio-ffmpeg 0.6.0 (bundles ffmpeg 7.0.2 static, libx264+libmp3lame), file 5.46.

1. `python3 scripts/gen_probes.py`  -> 26 files (text family, Pillow png/jpg,
   docx/xlsx/pptx, hand-built minimal PDF, hand-built silent-frame MP3 (later
   overwritten in step 3), zipfile/tar.gz, all 6 controls incl. ~10 MB md).
2. `python3 scripts/build_pe.py`    -> probes/probe_exe.exe (hand-built PE32;
   verified: `file` = PE32 executable (console) Intel i386; runtime UNTESTED).
3. `python3 scripts/build_mp3.py`   -> real libmp3lame encode (2 s silence).
4. `python3 scripts/build_mp4.py`   -> real libx264 encode (2 s, +faststart).
5. `cd preview_probe && sha256sum * > checksums.txt`

DETERMINISM NOTE: re-running these scripts yields functionally identical files
but NOT byte-identical ones — docx/xlsx/pptx/zip/tar.gz embed build timestamps,
mp3/mp4 encoders and the PE TimeDateStamp add entropy/time. Canonical
verification for a re-run: content marker "PROBE <ext> OK" + the Step-0
timestamp string, plus archive listings (unzip -l / tar tzf). The MANIFEST.*
files in THIS bundle are authoritative for THESE exact bytes.

## Controls (by design — MIME may mismatch extension)
- control_truncated_zip.txt: first 300 bytes of a valid zip (file -> application/zip)
- control_empty.md / control_empty.zip: 0 bytes (file -> inode/x-empty)
- control_probe ünïcødé spàce.md: space + non-ASCII in filename
- control_10mb.md: 9,999,970 bytes (~10 MB)
- control_cdn.html: links water.css from jsdelivr CDN (sandbox has no network;
  unstyled degrade expected, still counts as P)

## Human verdicts (Edge) — summary
P: rows 1-15, 18, 21, 22, 23, 24, 25, 27, 29   D: 16, 17, 19, 20, 26
DEFERRED: 28 (~10 MB) — presenting it coincided with a chat-load error
(Trace ID 137b693d-daa8, Visit ID 01a0a5e7-b58f-77ec-8820-34431d219455);
retry pending, verdict unresolved.
Findings vs spec: .rtf previews (spec said D); .ipynb previews as raw JSON/code
(no notebook renderer); routing is extension-based, not content-sniffed.
Full details: results/results_edge_2026-09-15.md
