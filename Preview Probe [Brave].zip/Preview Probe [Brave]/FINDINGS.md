# FINDINGS - Preview Probe [Brave] (2026-09-15)
All render verdicts are human-observed in-viewer; the agent side only proved
handoff (present_file -> success). Tally: 23 P / 5 D / 1 E of 29 rubric rows.

## Rubric-confirming (match spec)
md txt html py json csv png svg pdf docx pptx jpg mp3 mp4 -> P
zip tar.gz bin -> D

## Rubric OVERRULED / clarified (findings)
1 EXTENSION ROUTING, NO CONTENT SNIFFING. Zip bytes named .txt rendered as
  garbled TEXT (row 24). Viewer labelled a PE application/octet-stream while
  file(1) says application/vnd.microsoft.portable-executable.
2 .rtf previews as RAW SOURCE ({\rtf1\ansi...}); no RTF interpreter (spec said D).
3 .ipynb previews as RAW JSON; cells/outputs ignored (not a notebook render).
4 SPREADSHEET INCONSISTENT: .csv -> table; .xlsx -> plain text, no grid.
5 EMPTY FILES TOLERATED: 0-byte .md opened empty, no error; 0-byte .zip -> D.
6 FILE VISIBILITY = NAVIGATION (corrected). Viewer is single-file panel +
  dropdown workspace tree; artifacts/ collapsed by default and only the last
  presented file is shown. Earlier "invisible/no card" answers were navigation
  perception. See SCREENSHOTS.md (image-1..8). present_file success does not
  tell the agent which file the human has open.
7 ~10 MiB .md (10,000,006 B / 93,463 lines) = HARD CHAT CRASH, not truncation:
  "We couldn't load this chat ... Reset session and reload"; browser refresh
  required (Trace 41aa15f4-5cfaG, Visit 01a0a5d3-565c-763e-af65-52d07f32331d).
8 IN-APP PREVIEW HAS NETWORK ACCESS. control_cdn.html applied external
  Bootstrap 5.3.3 (bg-dark + display-4 + p-5 all took effect; image-8).
  Contradicts "sandboxed iframe, no network". Scope: proves CDN CSS loads in
  Brave; no packet-level/image control run.

## Method note
Present one file per turn so the intended file is open; batches deliver but
only the last file is shown and nested folders must be expanded.
