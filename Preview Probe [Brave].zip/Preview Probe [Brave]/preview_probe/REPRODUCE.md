# REPRODUCE - how the pack was made
Generators are in the parent of this folder (copied to generators/ in the zip):
  make_probe_pack.py  - writes the 22 ext probes + 6 controls
  make_artifacts.py   - writes the 12 real artifact rows + hand-built PE32
  verify_pack.py      - Step-2 integrity table + checksums.txt + INTEGRITY.txt

Order of operations at generation time:
  1. pip install python-pptx lameenc imageio-ffmpeg   # transient
  2. python3 make_probe_pack.py
  3. python3 make_artifacts.py      # writes sources + PE, self-verifies PE
  4. cd preview_probe/artifacts && ./build.sh && make   # real g++ build
     (output tee'd to build.log; dist/probe is the ELF)
  5. python3 verify_pack.py          # produces checksums.txt + INTEGRITY.txt

Determinism:
- All probes embed the fixed marker "PROBE <ext> OK Tue Sep 15 16:29:55 UTC 2026",
  so probe bytes are reproducible IF the same library versions are used.
- NOT bit-identical on regeneration: artifacts/build.log (build timestamps),
  artifacts/dist/probe ELF (BuildID), and any zip/tar internal timestamps.
  Therefore treat checksums.txt as the record of THIS run, not a cross-run oracle.
