// Tue Sep 15 16:29:55 UTC 2026
#include <iostream>
#include <string>
#include "probe.h"

int main() {
    const std::string tag = "artifacts";
    probe_run(tag.c_str());
    std::cout << "PROBE cpp OK " << tag << " " << probe_build_stamp()
              << std::endl;
    return 0;
}
