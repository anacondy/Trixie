#ifndef PROBE_H
#define PROBE_H
/* Tue Sep 15 16:29:55 UTC 2026 */
#ifdef __cplusplus
extern "C" {
#endif

/* Returns 0 on success; prints the probe marker to stdout. */
int probe_run(const char *tag);

const char *probe_build_stamp(void);

#ifdef __cplusplus
}
#endif
#endif /* PROBE_H */
