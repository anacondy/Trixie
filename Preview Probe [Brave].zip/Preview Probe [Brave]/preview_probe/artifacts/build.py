#!/usr/bin/env python3
# Tue Sep 15 16:29:55 UTC 2026
"""Drive the artifact build with Python instead of make."""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    os.makedirs(os.path.join(HERE, "dist"), exist_ok=True)
    cmd = ["g++", "-O2", "-Wall", "-Wextra", "-std=c++17",
           "-o", os.path.join(HERE, "dist", "probe"),
           os.path.join(HERE, "src", "main.cpp"),
           os.path.join(HERE, "src", "probe.c"),
           "-I" + os.path.join(HERE, "src")]
    subprocess.run(cmd, check=True)
    subprocess.run([os.path.join(HERE, "dist", "probe")], check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
