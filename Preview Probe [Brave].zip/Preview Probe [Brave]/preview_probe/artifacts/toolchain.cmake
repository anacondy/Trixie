# Tue Sep 15 16:29:55 UTC 2026
# Example cross toolchain file; unused by the native build run here.
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_C_COMPILER gcc)
set(CMAKE_CXX_COMPILER g++)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
