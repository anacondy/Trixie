@echo off
REM Tue Sep 15 16:29:55 UTC 2026
setlocal
cd /d %~dp0
if not exist dist mkdir dist
cl /nologo /W4 /O2 /Fe:dist\probe.exe src\main.cpp src\probe.c /Isrc
dist\probe.exe
endlocal
