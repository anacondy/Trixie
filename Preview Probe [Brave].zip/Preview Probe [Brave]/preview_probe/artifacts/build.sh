#!/usr/bin/env bash
# Tue Sep 15 16:29:55 UTC 2026
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p dist
g++ -O2 -Wall -Wextra -std=c++17 -o dist/probe src/main.cpp src/probe.c -Isrc
./dist/probe
