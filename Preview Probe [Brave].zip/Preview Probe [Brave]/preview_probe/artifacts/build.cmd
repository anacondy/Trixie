@echo off
REM Tue Sep 15 16:29:55 UTC 2026 -- cmd wrapper around build.bat
call "%~dp0build.bat"
exit /b %errorlevel%
