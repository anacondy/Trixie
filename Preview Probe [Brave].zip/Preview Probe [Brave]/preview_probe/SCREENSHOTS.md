# Screenshot ground truth (Brave, 2026-09-15) - user-attached image-1..8
1 image-1: viewer = single-file panel; after presenting .exe/.bin/.dat in a
  batch, the panel shows only probe_same_bytes.dat (last) as a download-only
  card "1.5 KB - application/octet-stream - This file type cannot be
  previewed in the workspace viewer. Download".
2 image-2: panel header dropdown = workspace tree; artifacts/ COLLAPSED;
  control_cdn.html highlighted. Nested files hidden until expanded.
3 image-3: chat shows inline file chip [probe.bin] inside the message text.
4 image-4: probe.bin rendered a download-only card "1.1 KB -
  application/octet-stream ... cannot be previewed ... Download". Confirms row 19.
5 image-5: dropdown expanded with artifacts/ open; probe_same_bytes.bin
  highlighted (copy + download icons on hover). Files ARE reachable.
6 image-6: dropdown expanded to artifacts/src; build.bat highlighted.
7 image-7: answer "Yes - the card appeared this time" checked; panel shows
  probe_same_bytes.bin "1.5 KB - application/octet-stream" download card.
8 image-8: control_cdn.html rendered WITH Bootstrap applied: dark background,
  oversized display-4 heading, p-5 padding, light text -> external CDN CSS
  loaded inside the preview (network access).
