# METADATA - Preview Probe [Brave] run
session_id (E2B_SANDBOX_ID): ie5tmq8jibvyinh0363wa
browser: Brave
step0_utc: Tue Sep 15 16:29:55 UTC 2026   (marker embedded in every probe)
run_date: 2026-09-15
rubric: uploads/preview_master_sheet.md (29-row consolidated spec)
rows: 40 in my table (22 ext probes + 6 controls + 12 real artifacts)

## Runtime environment (at generation)
python: 3.13.14
pillow: 12.3.0 (preinstalled)
python-docx: 1.1.2 (preinstalled)
openpyxl: 3.1.5 (preinstalled)
PyYAML: 6.0.3 (preinstalled)
nbformat: 5.10.4 (preinstalled)
python-pptx: 1.0.2 (PIP-INSTALLED at generation; NOT persisted)
lameenc: (PIP-INSTALLED at generation; NOT persisted; version not exposed)
imageio-ffmpeg static ffmpeg: v7.0.2 (PIP-INSTALLED; NOT persisted)
g++/gcc: (Debian 14.2.0-19) 14.2.0
mingw cross-compiler: NOT available (apt-get failed: no root) -> PE hand-assembled

## Persistence notes
- /home/user files persist across turns; installed pip packages and the
  artifacts/dist/ directory (excluded by snapshot) did NOT.
- probe.exe was therefore regenerated at artifacts/probe.exe (persists) and
  is byte-identical to the original (sha256(16)=0d41ef0ae744a999).
