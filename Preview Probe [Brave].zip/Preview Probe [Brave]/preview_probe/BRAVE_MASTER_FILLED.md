# Brave column - FINAL, all 29 rows complete (2026-09-15 in-viewer calibration)
Rubric: preview_master_sheet.md (29 rows). Filled from live answers only.
P = preview rendered | D = download only | E = error/blank/crash

| # | type / control | spec-expected | Brave | how it looked |
|---|---|---|---|---|
| 1 | .md | P | **P** | rendered as Markdown |
| 2 | .txt | P | **P** | text shown |
| 3 | .html | P | **P** | page rendered |
| 4 | .py | P | **P** | code view |
| 5 | .json | P (text/code) | **P** | formatted / syntax-highlighted |
| 6 | .csv | P | **P** | rendered as a TABLE (header + 2 rows) |
| 7 | .png | P | **P** | image rendered |
| 8 | .svg | P | **P** | drawn as an image, not XML source |
| 9 | .pdf | P | **P** | document rendered |
| 10 | .docx | P | **P** | document rendered |
| 11 | .xlsx | P | **P** | TEXT ONLY, no spreadsheet grid (spec expected a grid) |
| 12 | .pptx | P | **P** | slides rendered, slide 2 reachable |
| 13 | .jpg | P | **P** | image rendered |
| 14 | .mp3 | P | **P** | audio player with controls |
| 15 | .mp4 | P | **P** | video player, plays |
| 16 | .zip | D | **D** | download only (spec matched) |
| 17 | .tar.gz | D | **D** | download only (spec matched) |
| 18 | .rtf | D | **P** | SPEC WRONG - raw source shown ({\rtf1\ansi...}), no formatting |
| 19 | .exe | D | **D** | "cannot be previewed in the workspace viewer" - but see finding 6 |
| 20 | .bin | D | **D** | download only (spec matched) |
| 21 | .ipynb | D?/P? | **P** | RAW JSON (cells/nbformat/outputs), not a notebook render |
| 22 | .yaml | D?/P? | **P** | text/code shown |
| 23 | .log | D?/P? | **P** | text shown |
| 24 | zip-bytes as .txt | P vs D | **P** | GARBLED TEXT - extension routing, no content sniffing |
| 25 | 0-byte .md | P?/E? | **P** | opened, empty view, no error |
| 26 | 0-byte .zip | D?/E? | **D** | download only |
| 27 | space + unicode .md | P | **P** | content and filename (u-umlaut, i-diaeresis, CJK) both correct |
| 28 | ~10 MiB .md | P(trunc?)/E | **E** | CHAT CRASH - see finding 7. File was not re-opened. |
| 29 | .html + CDN css | P unstyled | **P** | RENDERED WITH THE CDN STYLESHEET APPLIED - see finding 8 |

## Findings that change the rubric
1. Extension routing, no content sniffing (row 24). Zip bytes named .txt
   were dumped as garbled text. Confirmed by row 19/.dat labelling: the
   viewer reported application/octet-stream for bytes that file(1) calls
   application/vnd.microsoft.portable-executable.
2. .rtf previews (spec said download-only) but as RAW SOURCE only - there
   is no RTF interpreter.
3. .ipynb previews as raw JSON. Notebook cells and stored outputs ignored.
4. Spreadsheet handling is inconsistent: .csv rendered as a table, .xlsx
   rendered as plain text with no grid.
5. Empty files are tolerated: 0-byte .md opened as an empty view with no
   error; 0-byte .zip went to download.
6. FILE VISIBILITY IS NAVIGATION, NOT DELIVERY FAILURE (corrected 2026-09-15
   using user screenshots image-1..8). The right-hand viewer shows ONE file
   at a time (the last presented) and exposes a dropdown listing the
   workspace tree; nested folders (artifacts/) are collapsed by default, so
   the .exe and .bin copies were present but not visible until expanded
   (image-2, 5, 6). After a batch present only the last file is in the panel
   (image-1 shows .dat). The earlier "invisible / no card" answers were
   navigation perception, not dropped handoffs; inline file chips do appear
   in chat (image-3) and probe.bin rendered a download card (image-4).
   Net: present_file "success" is real; the agent cannot know which file the
   human has open. The one-per-turn method note remains a courtesy, not a
   fix for drops.
7. ~10 MiB markdown is not survivable. 10,000,006 bytes / 93,463 lines
   produced: "Something went wrong. We couldn't load this chat. Please
   try again. Trace ID: 41aa15f4-5cfaG  Visit ID:
   01a0a5d3-565c-763e-af65-52d07f32331d  Try again  Still not working?
   Reset session and reload" - browser refresh required. Not truncation:
   a hard failure of the whole chat.

8. THE IN-APP PREVIEW HAS NETWORK ACCESS. control_cdn.html loaded
   Bootstrap 5.3.3 from cdn.jsdelivr.net inside the preview: dark
   background (bg-dark), an oversized heading (display-4, ~4.5rem) and
   wide page padding (p-5, ~3rem) all took effect. Three independent rules
   from an external file applying is conclusive that the stylesheet was
   fetched. This contradicts the "sandboxed iframe, no network" assumption.
   Scope caveat: the evidence is the rendered CSS effect; no packet-level
   or external-image control was run, so this proves CDN CSS loads in
   Brave, not that every external resource type loads.

## Method note for future runs
Present ONE file per turn so the human has the intended file open in the
single-file viewer; batches are fine for delivery but only the last file is
shown in the panel and nested folders must be expanded to browse them.
