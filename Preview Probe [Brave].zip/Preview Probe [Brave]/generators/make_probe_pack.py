#!/usr/bin/env python3
"""Generate the preview-probe pack (Step 1b) + control files.

Every probe is produced by a real encoder/serialiser (Pillow, python-docx,
openpyxl, python-pptx, nbformat, zipfile, tarfile, lameenc, imageio-ffmpeg's
static ffmpeg, hand-built PDF/PE writers). Nothing is produced by renaming.
"""
import hashlib
import io
import json
import os
import struct
import subprocess
import sys
import tarfile
import zipfile

TS = "Tue Sep 15 16:29:55 UTC 2026"  # Step-0 UTC timestamp
OUT = "/home/user/preview_probe"
os.makedirs(OUT, exist_ok=True)

MARK = "PROBE {} OK " + TS


def mark(ext):
    return MARK.format(ext)


def w(name, data):
    p = os.path.join(OUT, name)
    mode = "wb" if isinstance(data, (bytes, bytearray)) else "w"
    with open(p, mode, encoding="utf-8" if mode == "w" else None) as f:
        f.write(data)
    return p


# ---------------------------------------------------------------- text-ish ---
w("probe.md", "# probe.md\n\n%s\n\n- generated: %s\n" % (mark("md"), TS))
w("probe.txt", mark("txt") + "\n")
w(
    "probe.html",
    "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
    "<title>probe.html</title>\n</head>\n<body>\n<h1>%s</h1>\n"
    "<p>Generated %s</p>\n</body>\n</html>\n" % (mark("html"), TS),
)
w(
    "probe.py",
    '#!/usr/bin/env python3\n"""%s"""\n\n\ndef main() -> None:\n'
    '    print("%s")\n\n\nif __name__ == "__main__":\n    main()\n'
    % (mark("py"), mark("py")),
)
w(
    "probe.json",
    json.dumps(
        {"probe": "json", "marker": mark("json"), "generated_utc": TS, "rows": [1, 2, 3]},
        indent=2,
    )
    + "\n",
)
w("probe.csv", "id,marker,generated_utc\n1,%s,%s\n2,%s,%s\n"
  % (mark("csv"), TS, mark("csv"), TS))
w(
    "probe.svg",
    '<svg xmlns="http://www.w3.org/2000/svg" width="420" height="120" '
    'viewBox="0 0 420 120">\n<rect width="420" height="120" fill="#101820"/>\n'
    '<text x="20" y="52" font-family="monospace" font-size="26" fill="#7ee787">'
    "%s</text>\n<text x=\"20\" y=\"90\" font-family=\"monospace\" font-size=\"18\" "
    'fill="#c9d1d9">generated %s</text>\n</svg>\n' % (mark("svg"), TS),
)
w(
    "probe.rtf",
    "{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0 Courier New;}}\\f0\\fs24 "
    + mark("rtf")
    + "\\line generated " + TS + "\\par}",
)
w(
    "probe.yaml",
    "# %s\nprobe: yaml\nmarker: \"%s\"\ngenerated_utc: \"%s\"\n"
    "nested:\n  a: 1\n  b: [x, y, z]\n" % (mark("yaml"), mark("yaml"), TS),
)
w(
    "probe.log",
    "\n".join(
        [
            "%s INFO  probe run start" % TS,
            "%s INFO  %s" % (TS, mark("log")),
            "%s INFO  3 checks passed, 0 failed" % TS,
            "%s INFO  probe run end" % TS,
            "",
        ]
    ),
)
w(
    "probe.ipynb",
    json.dumps(
        {
            "cells": [
                {
                    "cell_type": "markdown",
                    "metadata": {},
                    "source": ["# probe.ipynb\n", mark("ipynb") + "\n"],
                },
                {
                    "cell_type": "code",
                    "execution_count": 1,
                    "metadata": {},
                    "outputs": [
                        {
                            "data": {"text/plain": ["'%s'" % mark("ipynb")]},
                            "metadata": {},
                            "output_type": "execute_result",
                            "execution_count": 1,
                        }
                    ],
                    "source": ['print("%s")' % mark("ipynb")],
                },
            ],
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3",
                },
                "language_info": {"name": "python", "version": "3.13.0"},
            },
            "nbformat": 4,
            "nbformat_minor": 5,
        },
        indent=1,
    ),
)

# ------------------------------------------------------------------- images ---
from PIL import Image, ImageDraw, PngImagePlugin  # noqa: E402

for ext, fmt, mode in (("png", "PNG", "RGB"), ("jpg", "JPEG", "RGB")):
    img = Image.new(mode, (640, 200), (16, 24, 32))
    d = ImageDraw.Draw(img)
    d.rectangle([8, 8, 632, 192], outline=(126, 231, 135), width=3)
    d.text((28, 70), mark(ext), fill=(201, 209, 217))
    d.text((28, 120), "generated " + TS, fill=(126, 231, 135))
    buf = io.BytesIO()
    if fmt == "PNG":
        # marker also stored as a real tEXt chunk so it is byte-verifiable
        info = PngImagePlugin.PngInfo()
        info.add_text("probe", mark(ext))
        info.add_text("generated_utc", TS)
        img.save(buf, format=fmt, pnginfo=info)
    else:
        # marker also stored as a real EXIF ImageDescription tag
        ex = Image.Exif()
        ex[0x010E] = mark(ext) + " generated " + TS
        img.save(buf, format=fmt, exif=ex, quality=92)
    w("probe." + ext, buf.getvalue())

# ---------------------------------------------------------------------- pdf ---
def minimal_pdf(text_lines):
    """Hand-built single-page PDF 1.4 with correct xref offsets."""
    content = "BT /F1 18 Tf 50 750 Td 14 TL\n"
    for i, line in enumerate(text_lines):
        esc = line.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
        content += "(%s) Tj%s\n" % (esc, "" if i == 0 else "")
        content += "T*\n" if i < len(text_lines) - 1 else ""
    content += "ET\n"
    objs = {
        1: b"<< /Type /Catalog /Pages 2 0 R >>",
        2: b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        3: b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] "
           b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
        4: b"<< /Length %d >>\nstream\n%s\nendstream"
           % (len(content.encode()), content.encode()),
        5: b"<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>",
    }
    out = io.BytesIO()
    out.write(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    offsets = {}
    for n in sorted(objs):
        offsets[n] = out.tell()
        out.write(b"%d 0 obj\n" % n + objs[n] + b"\nendobj\n")
    xref_pos = out.tell()
    out.write(b"xref\n0 %d\n" % (len(objs) + 1))
    out.write(b"0000000000 65535 f \n")
    for n in sorted(objs):
        out.write(b"%010d 00000 n \n" % offsets[n])
    out.write(
        b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n"
        % (len(objs) + 1, xref_pos)
    )
    return out.getvalue()


w("probe.pdf", minimal_pdf([mark("pdf"), "generated " + TS]))

# -------------------------------------------------------------- office docs ---
import docx  # noqa: E402
import openpyxl  # noqa: E402
import pptx  # noqa: E402

d = docx.Document()
d.add_heading("probe.docx", 0)
d.add_paragraph(mark("docx"))
d.add_paragraph("generated " + TS)
d.save(os.path.join(OUT, "probe.docx"))

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "probe"
ws.append(["id", "marker", "generated_utc"])
ws.append([1, mark("xlsx"), TS])
ws.append([2, "second row", TS])
wb.save(os.path.join(OUT, "probe.xlsx"))

prs = pptx.Presentation()
s1 = prs.slides.add_slide(prs.slide_layouts[0])
s1.shapes.title.text = "probe.pptx"
s1.placeholders[1].text = mark("pptx") + "\ngenerated " + TS
s2 = prs.slides.add_slide(prs.slide_layouts[1])
s2.shapes.title.text = "Second slide"
s2.placeholders[1].text = TS
prs.save(os.path.join(OUT, "probe.pptx"))

# ------------------------------------------------------------------- binary ---
w("probe.bin", mark("bin").encode("ascii") + b"\x00" + bytes(range(256)) * 4
  + hashlib.sha256(mark("bin").encode()).digest())

# ------------------------------------------------------------------ archive ---
zf_buf = io.BytesIO()
with zipfile.ZipFile(zf_buf, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("probe.txt", mark("zip") + "\n")
    z.writestr("nested/inner.txt", mark("zip") + "\n" + TS + "\n")
zf_bytes = zf_buf.getvalue()
w("probe.zip", zf_bytes)

tg_buf = io.BytesIO()
with tarfile.open(fileobj=tg_buf, mode="w:gz") as t:
    for nm in ("probe.txt", "nested/inner.txt"):
        payload = (mark("tar.gz") + "\n" + TS + "\n").encode()
        info = tarfile.TarInfo(nm)
        info.size = len(payload)
        t.addfile(info, io.BytesIO(payload))
w("probe.tar.gz", tg_buf.getvalue())

# -------------------------------------------------------------------- audio ---
import lameenc  # noqa: E402

SR = 44100
DUR = 2.0
import math  # noqa: E402

n = int(SR * DUR)
pcm = bytearray()
for i in range(n):
    v = int(12000 * math.sin(2 * math.pi * 440 * i / SR))
    pcm += struct.pack("<hh", v, v)
enc = lameenc.Encoder()
enc.set_bit_rate(128)
enc.set_in_sample_rate(SR)
enc.set_channels(2)
enc.set_quality(2)
mp3 = enc.encode(bytes(pcm)) + enc.flush()


def id3v2(title):
    payload = b"\x00\x03" + title.encode("utf-8")  # encoding byte + TIT2 text
    frame = b"TIT2" + struct.pack(">I", len(payload)) + b"\x00\x00" + payload
    body = frame
    size = len(body)
    syn = b""
    v = size
    for _ in range(4):
        syn = bytes([v & 0x7F]) + syn
        v >>= 7
    return b"ID3\x04\x00\x00" + syn + body


w("probe.mp3", id3v2(mark("mp3")) + mp3)

# -------------------------------------------------------------------- video ---
import imageio_ffmpeg  # noqa: E402

FF = imageio_ffmpeg.get_ffmpeg_exe()
mp4 = os.path.join(OUT, "probe.mp4")
cmd = [
    FF, "-y", "-hide_banner", "-loglevel", "error",
    "-f", "lavfi", "-i", "testsrc=duration=2:size=320x240:rate=15",
    "-f", "lavfi", "-i", "sine=frequency=440:duration=2",
    "-vf", "drawtext=text='%s':fontsize=18:fontcolor=white:x=10:y=200"
           % mark("mp4").replace(":", r"\:").replace("'", ""),
    "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac",
    "-metadata", "title=%s" % mark("mp4"),
    "-movflags", "+faststart", mp4,
]
r = subprocess.run(cmd, capture_output=True, text=True)
drawtext_ok = r.returncode == 0
if not drawtext_ok:
    cmd = [c for c in cmd if not c.startswith("drawtext=")]
    cmd.remove("-vf")
    r = subprocess.run(cmd, capture_output=True, text=True)
print("ffmpeg drawtext_ok=%s rc=%s %s" % (drawtext_ok, r.returncode,
                                          r.stderr.strip()[:200]))

# ----------------------------------------------------------------- controls ---
w("control_truncated_zip_as_txt.txt", zf_bytes[:300])  # zip head, .txt name
w("control_empty.md", b"")
w("control_empty.zip", b"")
w("control spaced \u00fcn\u00efcode \u6d4b\u8bd5.md",
  mark("md") + "\ncontrol: filename has a space and non-ASCII chars\n" + TS + "\n")

target = 10_000_000
lines = []
total = 0
i = 0
lines.append("# control_large_10mb.md\n\n%s\n\ngenerated %s\n\n" % (mark("md"), TS))
total = sum(len(x) for x in lines)
while total < target:
    row = ("%08d | filler line for large-file control | %s | sha256seed=%s\n"
           % (i, TS, hashlib.sha256(str(i).encode()).hexdigest()[:16]))
    lines.append(row)
    total += len(row)
    i += 1
w("control_large_10mb.md", "".join(lines))

w(
    "control_cdn.html",
    "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n"
    "<title>control_cdn.html</title>\n"
    "<link rel=\"stylesheet\" "
    "href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css\" "
    "integrity=\"sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH\" "
    "crossorigin=\"anonymous\">\n</head>\n<body class=\"bg-dark text-light p-5\">\n"
    "<h1 class=\"display-4\">%s</h1>\n<p>Control: external CDN stylesheet; "
    "expect graceful unstyled degrade when the viewer blocks network.</p>\n"
    "<p>generated %s</p>\n</body>\n</html>\n" % (mark("html"), TS),
)

print("standard pack + controls written to", OUT)
print("files:", len(os.listdir(OUT)))
