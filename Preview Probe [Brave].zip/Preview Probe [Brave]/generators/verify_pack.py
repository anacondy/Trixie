#!/usr/bin/env python3
"""Step 2 - integrity table + structural validation + checksums.txt."""
import hashlib
import json
import os
import subprocess
import tarfile
import zipfile

TS = "Tue Sep 15 16:29:55 UTC 2026"
ROOT = "/home/user/preview_probe"

ROWS = [
    ("01", "probe.md", "probe", "md"),
    ("02", "probe.txt", "probe", "txt"),
    ("03", "probe.html", "probe", "html"),
    ("04", "probe.py", "probe", "py"),
    ("05", "probe.json", "probe", "json"),
    ("06", "probe.csv", "probe", "csv"),
    ("07", "probe.png", "probe", "png"),
    ("08", "probe.svg", "probe", "svg"),
    ("09", "probe.pdf", "probe", "pdf"),
    ("10", "probe.docx", "probe", "docx"),
    ("11", "probe.xlsx", "probe", "xlsx"),
    ("12", "probe.pptx", "probe", "pptx"),
    ("13", "probe.jpg", "probe", "jpg"),
    ("14", "probe.mp3", "probe", "mp3"),
    ("15", "probe.mp4", "probe", "mp4"),
    ("16", "probe.zip", "probe", "zip"),
    ("17", "probe.tar.gz", "probe", "tar.gz"),
    ("18", "probe.rtf", "probe", "rtf"),
    ("19", "probe.bin", "probe", "bin"),
    ("20", "probe.ipynb", "probe", "ipynb"),
    ("21", "probe.yaml", "probe", "yaml"),
    ("22", "probe.log", "probe", "log"),
    ("23", "control_truncated_zip_as_txt.txt", "control", "truncated-zip-as-.txt"),
    ("24", "control_empty.md", "control", "0-byte .md"),
    ("25", "control_empty.zip", "control", "0-byte .zip"),
    ("26", "control spaced \u00fcn\u00efcode \u6d4b\u8bd5.md", "control",
     "space + non-ASCII name"),
    ("27", "control_large_10mb.md", "control", "~10 MB .md"),
    ("28", "control_cdn.html", "control", "CDN stylesheet link"),
    ("R01", "artifacts/src/probe.h", "artifact", ".h"),
    ("R02", "artifacts/src/probe.c", "artifact", ".c"),
    ("R03", "artifacts/src/main.cpp", "artifact", ".cpp"),
    ("R04", "artifacts/CMakeLists.txt", "artifact", "CMakeLists"),
    ("R05", "artifacts/toolchain.cmake", "artifact", ".cmake"),
    ("R06", "artifacts/Makefile", "artifact", "Makefile"),
    ("R07", "artifacts/build.sh", "artifact", ".sh"),
    ("R08", "artifacts/build.py", "artifact", ".py"),
    ("R09", "artifacts/build.bat", "artifact", ".bat"),
    ("R10", "artifacts/build.cmd", "artifact", ".cmd"),
    ("R11", "artifacts/build.log", "artifact", ".log (real build output)"),
    ("R12", "artifacts/probe.exe", "artifact", "exe"),
]


def sh(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def mime_of(path):
    r = sh(["file", "--mime-type", "-b", path])
    return r.stdout.strip() or "?"


def sha16(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


def check(rel, kind, ext):
    """Return (status, detail). Structural check, MIME-independent."""
    p = os.path.join(ROOT, rel)
    size = os.path.getsize(p)
    head = open(p, "rb").read(64)
    if kind == "control" and size == 0:
        return "EMPTY-BY-DESIGN", "0 bytes"
    if rel.endswith(".zip"):
        try:
            r = sh(["unzip", "-l", p])
            names = [n for n in zipfile.ZipFile(p).namelist()]
            return ("ZIP-OK" if r.returncode == 0 else "ZIP-FAIL"), \
                "unzip rc=%d members=%s" % (r.returncode, names)
        except Exception as e:
            return "ZIP-FAIL", "%s: %s" % (type(e).__name__, e)
    if rel.endswith(".tar.gz"):
        r = sh(["tar", "tzf", p])
        return ("TARGZ-OK" if r.returncode == 0 else "TARGZ-FAIL"), \
            "tar rc=%d members=%s" % (r.returncode, r.stdout.split())
    if ext == "truncated-zip-as-.txt":
        is_zip = head[:2] == b"PK"
        try:
            zipfile.ZipFile(p).namelist()
            opens = True
        except Exception as e:
            opens = "%s" % type(e).__name__
        return "TRUNCATED-BY-DESIGN", \
            "PK magic=%s, full parse=%s (expected failure: only first 300 bytes)" \
            % (is_zip, opens)
    if ext in ("png",):
        return ("PNG-OK" if head[:8] == b"\x89PNG\r\n\x1a\n" else "PNG-FAIL"), \
            "magic=%r size=%d" % (head[:8], size)
    if ext in ("jpg",):
        return ("JPEG-OK" if head[:2] == b"\xff\xd8" else "JPEG-FAIL"), \
            "magic=%r size=%d" % (head[:2], size)
    if ext == "pdf":
        body = open(p, "rb").read()
        return ("PDF-OK" if head[:5] == b"%PDF-" and b"%%EOF" in body[-64:]
                else "PDF-FAIL"), "hdr=%r has_xref=%s has_eof=%s" % (
                    head[:8], b"xref" in body, b"%%EOF" in body[-64:])
    if ext in ("docx", "xlsx", "pptx"):
        try:
            z = zipfile.ZipFile(p)
            bad = z.testzip()
            return "OOXML-OK", "%d parts, testzip=%s" % (len(z.namelist()), bad)
        except Exception as e:
            return "OOXML-FAIL", "%s: %s" % (type(e).__name__, e)
    if ext == "mp3":
        body = open(p, "rb").read()
        id3 = body[:3] == b"ID3"
        off = 10 + body[6:10][0] * 0 if id3 else 0
        if id3:  # synchsafe size
            s = body[6:10]
            off = 10 + ((s[0] << 21) | (s[1] << 14) | (s[2] << 7) | s[3])
        sync = body[off] == 0xFF and (body[off + 1] & 0xE0) == 0xE0
        return ("MP3-OK" if id3 and sync else "MP3-FAIL"), \
            "ID3v2=%s frame_sync@%d=%s" % (id3, off, sync)
    if ext == "mp4":
        body = open(p, "rb").read()
        box = body[4:8]
        return ("MP4-OK" if box == b"ftyp" else "MP4-FAIL"), \
            "first_box=%r brand=%s" % (box, body[8:12].decode("ascii", "replace"))
    if ext == "ipynb":
        try:
            nb = json.load(open(p))
            return "IPYNB-OK", "nbformat=%s cells=%d" % (
                nb.get("nbformat"), len(nb.get("cells", [])))
        except Exception as e:
            return "IPYNB-FAIL", str(e)
    if ext == "json":
        try:
            json.load(open(p))
            return "JSON-OK", "parses"
        except Exception as e:
            return "JSON-FAIL", str(e)
    if ext == "yaml":
        try:
            import yaml
            yaml.safe_load(open(p))
            return "YAML-OK", "parses"
        except Exception as e:
            return "YAML-FAIL", str(e)
    if ext == "exe":
        body = open(p, "rb").read()
        import struct
        pe = struct.unpack_from("<I", body, 0x3C)[0]
        ok = body[:2] == b"MZ" and body[pe:pe + 4] == b"PE\x00\x00"
        return ("PE-OK" if ok else "PE-FAIL"), \
            "MZ=%s PE_sig@%d=%s" % (body[:2] == b"MZ", pe, body[pe:pe + 4])
    if ext == "bin":
        body = open(p, "rb").read()
        return "BIN-OK", "%d bytes, marker=%s" % (
            size, b"PROBE bin OK" in body)
    # plain text-ish
    try:
        txt = open(p, encoding="utf-8").read()
    except UnicodeDecodeError as e:
        return "TEXT-FAIL", str(e)
    return "TEXT-OK", "%d chars" % len(txt)


def marker_ok(rel, ext, kind):
    """Locate the literal marker; containers are inspected inside."""
    if kind == "control":
        return "n/a"
    p = os.path.join(ROOT, rel)
    want = "PROBE %s OK" % ext
    body = open(p, "rb").read()
    if want in body.decode("latin-1"):
        return "yes (raw bytes)"
    try:
        if ext == "png":
            from PIL import PngImagePlugin
            txt = PngImagePlugin.PngImageFile(open(p, "rb")).text
            return "yes (tEXt chunk %s)" % sorted(txt) if want in str(txt) \
                else "no"
        if ext == "jpg":
            from PIL import Image
            desc = Image.open(p).getexif().get(0x010E, "")
            return "yes (EXIF ImageDescription)" if want in str(desc) else "no"
        if ext in ("docx", "xlsx", "pptx"):
            z = zipfile.ZipFile(p)
            hits = [n for n in z.namelist()
                    if want in z.read(n).decode("utf-8", "replace")]
            return "yes (in %s)" % ",".join(hits) if hits else "no"
        if ext == "zip":
            z = zipfile.ZipFile(p)
            hits = [n for n in z.namelist()
                    if want in z.read(n).decode("utf-8", "replace")]
            return "yes (in %s)" % ",".join(hits) if hits else "no"
        if ext == "tar.gz":
            with tarfile.open(p) as t:
                hits = [m.name for m in t.getmembers()
                        if want in t.extractfile(m).read().decode()]
            return "yes (in %s)" % ",".join(hits) if hits else "no"
    except Exception as e:
        return "check-error: %s" % type(e).__name__
    return "no"


print("n    | path                                                            "
      "| bytes      | sha256(16)       | mime (file --mime-type -b)  | status")
print("-" * 132)
total = 0
checksum_lines = ["# preview_probe checksums - generated %s" % TS,
                  "# sha256  bytes  path"]
notes = []
for n, rel, kind, ext in ROWS:
    p = os.path.join(ROOT, rel)
    size = os.path.getsize(p)
    total += size
    status, detail = check(rel, kind, ext)
    m = mime_of(p)
    print("%-4s | %-63s | %10d | %-16s | %-25s | %s"
          % (n, rel, size, sha16(p), m, status))
    notes.append((n, rel, size, sha16(p), m, status, detail, kind, ext))
    checksum_lines.append("%s  %8d  %s" % (sha16(p), size, rel))

print("-" * 132)
print("rows=%d  total_bytes=%d (%.2f MB)" % (len(ROWS), total, total / 1048576))

print("\nStructural detail (and MIME expectations):")
for n, rel, size, h, m, status, detail, kind, ext in notes:
    print("  %-3s %-38s %-22s %-24s %s" % (n, rel[:38], status, m, detail))

print("\nMarker present in probe payload (PROBE <ext> OK):")
for n, rel, size, h, m, status, detail, kind, ext in notes:
    if kind == "probe":
        print("  %s %-16s marker=%s" % (n, rel, marker_ok(rel, ext, kind)))

with open(os.path.join(ROOT, "checksums.txt"), "w") as f:
    f.write("\n".join(checksum_lines) + "\n")
print("\nchecksums.txt written (%d rows)" % (len(checksum_lines) - 2))
