#!/usr/bin/env python3
"""Emit the REAL ARTIFACT rows (R01..R12): a small C/C++ project that is
actually compiled here, plus its build scripts, and a hand-built PE image."""
import os
import struct

A = "/home/user/preview_probe/artifacts"
os.makedirs(os.path.join(A, "src"), exist_ok=True)
os.makedirs(os.path.join(A, "dist"), exist_ok=True)
TS = "Tue Sep 15 16:29:55 UTC 2026"


def w(rel, data):
    p = os.path.join(A, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "wb" if isinstance(data, bytes) else "w", encoding="utf-8"
              if not isinstance(data, bytes) else None) as f:
        f.write(data)
    return p


w("src/probe.h", """#ifndef PROBE_H
#define PROBE_H
/* %s */
#ifdef __cplusplus
extern "C" {
#endif

/* Returns 0 on success; prints the probe marker to stdout. */
int probe_run(const char *tag);

const char *probe_build_stamp(void);

#ifdef __cplusplus
}
#endif
#endif /* PROBE_H */
""" % TS)

w("src/probe.c", """/* %s */
#include <stdio.h>
#include "probe.h"

const char *probe_build_stamp(void) { return "%s"; }

int probe_run(const char *tag) {
    printf("PROBE c OK [%%s] %%s\\n", tag, probe_build_stamp());
    return 0;
}
""" % (TS, TS))

w("src/main.cpp", """// %s
#include <iostream>
#include <string>
#include "probe.h"

int main() {
    const std::string tag = "artifacts";
    probe_run(tag.c_str());
    std::cout << "PROBE cpp OK " << tag << " " << probe_build_stamp()
              << std::endl;
    return 0;
}
""" % TS)

w("CMakeLists.txt", """# %s
cmake_minimum_required(VERSION 3.16)
project(preview_probe C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_CXX_STANDARD 17)

add_executable(probe src/main.cpp src/probe.c)
target_include_directories(probe PRIVATE src)

install(TARGETS probe RUNTIME DESTINATION bin)
""" % TS)

w("toolchain.cmake", """# %s
# Example cross toolchain file; unused by the native build run here.
set(CMAKE_SYSTEM_NAME Linux)
set(CMAKE_C_COMPILER gcc)
set(CMAKE_CXX_COMPILER g++)
set(CMAKE_FIND_ROOT_PATH_MODE_PROGRAM NEVER)
""" % TS)

w("Makefile", """# %s
CC      ?= gcc
CXX     ?= g++
CFLAGS  ?= -O2 -Wall -Wextra
CXXFLAGS ?= -O2 -Wall -Wextra -std=c++17

probe: src/main.cpp src/probe.c src/probe.h
\t$(CXX) $(CXXFLAGS) -o dist/probe src/main.cpp src/probe.c -Isrc

clean:
\trm -f dist/probe

.PHONY: clean
""" % TS)

w("build.sh", """#!/usr/bin/env bash
# %s
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p dist
g++ -O2 -Wall -Wextra -std=c++17 -o dist/probe src/main.cpp src/probe.c -Isrc
./dist/probe
""" % TS)

w("build.py", """#!/usr/bin/env python3
# %s
\"\"\"Drive the artifact build with Python instead of make.\"\"\"
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def main() -> int:
    os.makedirs(os.path.join(HERE, "dist"), exist_ok=True)
    cmd = ["g++", "-O2", "-Wall", "-Wextra", "-std=c++17",
           "-o", os.path.join(HERE, "dist", "probe"),
           os.path.join(HERE, "src", "main.cpp"),
           os.path.join(HERE, "src", "probe.c"),
           "-I" + os.path.join(HERE, "src")]
    subprocess.run(cmd, check=True)
    subprocess.run([os.path.join(HERE, "dist", "probe")], check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
""" % TS)

w("build.bat", """@echo off
REM %s
setlocal
cd /d %%~dp0
if not exist dist mkdir dist
cl /nologo /W4 /O2 /Fe:dist\\probe.exe src\\main.cpp src\\probe.c /Isrc
dist\\probe.exe
endlocal
""" % TS)

w("build.cmd", """@echo off
REM %s -- cmd wrapper around build.bat
call "%%~dp0build.bat"
exit /b %%errorlevel%%
""" % TS)

# --------------------------------------------------------------- hand-built PE
def build_pe() -> bytes:
    """Minimal but structurally valid PE32 console image (hand-assembled)."""
    text = b"\xb8\x00\x00\x40\x00"          # mov eax, 0x400000
    text += b"\xc3"                          # ret
    text += (b"PROBE exe OK %s\x00" % TS.encode())
    text += b"\x00" * (16 - (len(text) % 16))

    image_base = 0x00400000
    file_align = 0x0200
    sect_align = 0x1000
    headers_size = 0x0400
    entry = image_base + sect_align  # .text virtual address

    # DOS header is exactly 0x40 bytes; e_lfanew points at 0x80, and the DOS
    # stub occupies 0x40..0x7F so it cannot overwrite the PE signature.
    dos = bytearray(0x40)
    dos[0:2] = b"MZ"
    struct.pack_into("<I", dos, 0x3C, 0x80)
    stub = b"This program cannot be run in DOS mode.\r\n$"
    dos += stub + b"\x00" * (0x40 - len(stub))
    assert len(dos) == 0x80, len(dos)

    pe_sig = b"PE\x00\x00"
    coff = struct.pack(
        "<HHIIIHH", 0x014C, 1, 0x68B4B700, 0, 0, 0xE0, 0x0102
    )  # i386, 1 section, opt hdr size 0xE0, characteristics EXEC|32BIT|CONSOLE
    opt = bytearray(0xE0)  # PE32 optional header + 16 data directories
    struct.pack_into("<H", opt, 0x00, 0x010B)          # PE32 magic
    opt[0x02], opt[0x03] = 14, 0                       # linker version
    struct.pack_into("<I", opt, 0x04, len(text))       # SizeOfCode
    struct.pack_into("<I", opt, 0x08, len(text))       # SizeOfInitializedData
    struct.pack_into("<I", opt, 0x0C, 0)               # SizeOfUninitializedData
    struct.pack_into("<I", opt, 0x10, entry)           # AddressOfEntryPoint
    struct.pack_into("<I", opt, 0x14, sect_align)      # BaseOfCode
    struct.pack_into("<I", opt, 0x18, 0)               # BaseOfData
    struct.pack_into("<I", opt, 0x1C, image_base)
    struct.pack_into("<I", opt, 0x20, sect_align)
    struct.pack_into("<I", opt, 0x24, file_align)
    struct.pack_into("<H", opt, 0x28, 6)               # MajorOSVersion
    struct.pack_into("<H", opt, 0x2A, 0)
    struct.pack_into("<H", opt, 0x2C, 0)               # MajorImageVersion
    struct.pack_into("<H", opt, 0x2E, 0)
    struct.pack_into("<H", opt, 0x30, 6)               # MajorSubsystemVersion
    struct.pack_into("<H", opt, 0x32, 0)
    struct.pack_into("<I", opt, 0x34, 0)               # Win32VersionValue
    struct.pack_into("<I", opt, 0x38, headers_size + sect_align)  # SizeOfImage
    struct.pack_into("<I", opt, 0x3C, headers_size)    # SizeOfHeaders
    struct.pack_into("<I", opt, 0x40, 0)               # CheckSum
    struct.pack_into("<H", opt, 0x44, 3)               # Subsystem: CONSOLE
    struct.pack_into("<H", opt, 0x46, 0x0040)          # DllCharacteristics
    struct.pack_into("<I", opt, 0x48, 0x100000)        # SizeOfStackReserve
    struct.pack_into("<I", opt, 0x4C, 0x1000)
    struct.pack_into("<I", opt, 0x50, 0x100000)        # SizeOfHeapReserve
    struct.pack_into("<I", opt, 0x54, 0x1000)
    struct.pack_into("<I", opt, 0x58, 0)               # LoaderFlags
    struct.pack_into("<I", opt, 0x5C, 16)              # NumberOfRvaAndSizes

    sect = bytearray(40)
    sect[0:6] = b".text\x00"
    struct.pack_into("<I", sect, 0x08, len(text))       # VirtualSize
    struct.pack_into("<I", sect, 0x0C, sect_align)      # VirtualAddress
    struct.pack_into("<I", sect, 0x10, len(text))       # SizeOfRawData
    struct.pack_into("<I", sect, 0x14, headers_size)    # PointerToRawData
    struct.pack_into("<I", sect, 0x24, 0xE0000020)      # CNT_CODE|EXECUTE|READ

    head = bytes(dos) + pe_sig + coff + bytes(opt) + bytes(sect)
    head += b"\x00" * (headers_size - len(head))
    return head + text + b"\x00" * (file_align - len(text))


w("dist/probe.exe", build_pe())


def verify_pe(path):
    d = open(path, "rb").read()
    assert d[:2] == b"MZ", "bad DOS magic"
    pe_off = struct.unpack_from("<I", d, 0x3C)[0]
    assert d[pe_off:pe_off + 4] == b"PE\x00\x00", "bad PE signature at e_lfanew"
    machine, nsec, _, _, _, optsz, _ = struct.unpack_from("<HHIIIHH", d, pe_off + 4)
    assert machine == 0x14C, hex(machine)
    so = pe_off + 24 + optsz
    name = d[so:so + 8].rstrip(b"\x00")
    _, vaddr, rawsz, rawptr = struct.unpack_from("<IIII", d, so + 8)
    payload = d[rawptr:rawptr + rawsz]
    assert b"PROBE exe OK" in payload, "marker missing from .text"
    subsystem, = struct.unpack_from("<H", d, pe_off + 24 + 0x44)
    sizeof_img, sizeof_hdr = struct.unpack_from("<II", d, pe_off + 24 + 0x38)
    assert subsystem == 3, "subsystem=%d (expected 3 CONSOLE)" % subsystem
    print("PE verified: machine=0x%04X subsystem=%d sections=%d section0=%s "
          "vaddr=0x%06X entry=0x%08X SizeOfImage=0x%X SizeOfHeaders=0x%X "
          "size=%d bytes" % (
              machine, subsystem, nsec, name.decode(), vaddr,
              struct.unpack_from("<I", d, pe_off + 24 + 16)[0],
              sizeof_img, sizeof_hdr, len(d)))


verify_pe(os.path.join(A, "dist", "probe.exe"))

print("artifacts written under", A)
for root, _, files in os.walk(A):
    for f in sorted(files):
        p = os.path.join(root, f)
        print("  %-46s %8d" % (os.path.relpath(p, A), os.path.getsize(p)))
